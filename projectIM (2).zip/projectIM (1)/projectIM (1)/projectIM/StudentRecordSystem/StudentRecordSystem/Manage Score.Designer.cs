﻿namespace StudentRecordSystem
{
    partial class ManageScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_mainmngScore = new System.Windows.Forms.Panel();
            this.panel_mgnScrocebuttom = new System.Windows.Forms.Panel();
            this.button_mngScoreClear = new System.Windows.Forms.Button();
            this.button_mngScoreDelete = new System.Windows.Forms.Button();
            this.button_mngScoreUpdate = new System.Windows.Forms.Button();
            this.label_mngScoreStudID = new System.Windows.Forms.Label();
            this.textBox_mngScoreStudentId = new System.Windows.Forms.TextBox();
            this.textBox_mngScoreMarks = new System.Windows.Forms.TextBox();
            this.label_subMarks = new System.Windows.Forms.Label();
            this.textBox_mngScoreSubjectId = new System.Windows.Forms.TextBox();
            this.label_mngScoreSubjectID = new System.Windows.Forms.Label();
            this.comboBox_mngScoreSubjectName = new System.Windows.Forms.ComboBox();
            this.label_mngScoreSubName = new System.Windows.Forms.Label();
            this.comboBox_mngScoreTeacherName = new System.Windows.Forms.ComboBox();
            this.label_mngScoreTeacher = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_manageScore = new System.Windows.Forms.Panel();
            this.botton_mngScoreBack = new System.Windows.Forms.Button();
            this.label_manageScore = new System.Windows.Forms.Label();
            this.label_assessmentTtype = new System.Windows.Forms.Label();
            this.textBox_mngeAssessmentType = new System.Windows.Forms.TextBox();
            this.panel_mainmngScore.SuspendLayout();
            this.panel_mgnScrocebuttom.SuspendLayout();
            this.panel_manageScore.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_mainmngScore
            // 
            this.panel_mainmngScore.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel_mainmngScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_mainmngScore.Controls.Add(this.panel_mgnScrocebuttom);
            this.panel_mainmngScore.Controls.Add(this.panel1);
            this.panel_mainmngScore.Controls.Add(this.panel_manageScore);
            this.panel_mainmngScore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_mainmngScore.Location = new System.Drawing.Point(0, 0);
            this.panel_mainmngScore.Name = "panel_mainmngScore";
            this.panel_mainmngScore.Size = new System.Drawing.Size(884, 611);
            this.panel_mainmngScore.TabIndex = 0;
            // 
            // panel_mgnScrocebuttom
            // 
            this.panel_mgnScrocebuttom.Controls.Add(this.textBox_mngeAssessmentType);
            this.panel_mgnScrocebuttom.Controls.Add(this.label_assessmentTtype);
            this.panel_mgnScrocebuttom.Controls.Add(this.button_mngScoreClear);
            this.panel_mgnScrocebuttom.Controls.Add(this.button_mngScoreDelete);
            this.panel_mgnScrocebuttom.Controls.Add(this.button_mngScoreUpdate);
            this.panel_mgnScrocebuttom.Controls.Add(this.label_mngScoreStudID);
            this.panel_mgnScrocebuttom.Controls.Add(this.textBox_mngScoreStudentId);
            this.panel_mgnScrocebuttom.Controls.Add(this.textBox_mngScoreMarks);
            this.panel_mgnScrocebuttom.Controls.Add(this.label_subMarks);
            this.panel_mgnScrocebuttom.Controls.Add(this.textBox_mngScoreSubjectId);
            this.panel_mgnScrocebuttom.Controls.Add(this.label_mngScoreSubjectID);
            this.panel_mgnScrocebuttom.Controls.Add(this.comboBox_mngScoreSubjectName);
            this.panel_mgnScrocebuttom.Controls.Add(this.label_mngScoreSubName);
            this.panel_mgnScrocebuttom.Controls.Add(this.comboBox_mngScoreTeacherName);
            this.panel_mgnScrocebuttom.Controls.Add(this.label_mngScoreTeacher);
            this.panel_mgnScrocebuttom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_mgnScrocebuttom.Location = new System.Drawing.Point(0, 373);
            this.panel_mgnScrocebuttom.Name = "panel_mgnScrocebuttom";
            this.panel_mgnScrocebuttom.Size = new System.Drawing.Size(882, 236);
            this.panel_mgnScrocebuttom.TabIndex = 34;
            // 
            // button_mngScoreClear
            // 
            this.button_mngScoreClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_mngScoreClear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_mngScoreClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngScoreClear.ForeColor = System.Drawing.Color.White;
            this.button_mngScoreClear.Location = new System.Drawing.Point(562, 185);
            this.button_mngScoreClear.Name = "button_mngScoreClear";
            this.button_mngScoreClear.Size = new System.Drawing.Size(96, 31);
            this.button_mngScoreClear.TabIndex = 75;
            this.button_mngScoreClear.Text = "Clear";
            this.button_mngScoreClear.UseVisualStyleBackColor = false;
            // 
            // button_mngScoreDelete
            // 
            this.button_mngScoreDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_mngScoreDelete.BackColor = System.Drawing.Color.Green;
            this.button_mngScoreDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngScoreDelete.ForeColor = System.Drawing.Color.White;
            this.button_mngScoreDelete.Location = new System.Drawing.Point(766, 185);
            this.button_mngScoreDelete.Name = "button_mngScoreDelete";
            this.button_mngScoreDelete.Size = new System.Drawing.Size(96, 31);
            this.button_mngScoreDelete.TabIndex = 74;
            this.button_mngScoreDelete.Text = "Delete";
            this.button_mngScoreDelete.UseVisualStyleBackColor = false;
            // 
            // button_mngScoreUpdate
            // 
            this.button_mngScoreUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_mngScoreUpdate.BackColor = System.Drawing.Color.Red;
            this.button_mngScoreUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngScoreUpdate.ForeColor = System.Drawing.Color.White;
            this.button_mngScoreUpdate.Location = new System.Drawing.Point(664, 185);
            this.button_mngScoreUpdate.Name = "button_mngScoreUpdate";
            this.button_mngScoreUpdate.Size = new System.Drawing.Size(96, 31);
            this.button_mngScoreUpdate.TabIndex = 73;
            this.button_mngScoreUpdate.Text = "Update";
            this.button_mngScoreUpdate.UseVisualStyleBackColor = false;
            // 
            // label_mngScoreStudID
            // 
            this.label_mngScoreStudID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngScoreStudID.AutoSize = true;
            this.label_mngScoreStudID.Location = new System.Drawing.Point(51, 59);
            this.label_mngScoreStudID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_mngScoreStudID.Name = "label_mngScoreStudID";
            this.label_mngScoreStudID.Size = new System.Drawing.Size(89, 19);
            this.label_mngScoreStudID.TabIndex = 72;
            this.label_mngScoreStudID.Text = "Student ID:";
            // 
            // textBox_mngScoreStudentId
            // 
            this.textBox_mngScoreStudentId.Location = new System.Drawing.Point(163, 59);
            this.textBox_mngScoreStudentId.Name = "textBox_mngScoreStudentId";
            this.textBox_mngScoreStudentId.Size = new System.Drawing.Size(147, 27);
            this.textBox_mngScoreStudentId.TabIndex = 71;
            // 
            // textBox_mngScoreMarks
            // 
            this.textBox_mngScoreMarks.Location = new System.Drawing.Point(542, 64);
            this.textBox_mngScoreMarks.Name = "textBox_mngScoreMarks";
            this.textBox_mngScoreMarks.Size = new System.Drawing.Size(202, 27);
            this.textBox_mngScoreMarks.TabIndex = 70;
            // 
            // label_subMarks
            // 
            this.label_subMarks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subMarks.AutoSize = true;
            this.label_subMarks.Location = new System.Drawing.Point(416, 67);
            this.label_subMarks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subMarks.Name = "label_subMarks";
            this.label_subMarks.Size = new System.Drawing.Size(110, 19);
            this.label_subMarks.TabIndex = 69;
            this.label_subMarks.Text = "Final Grades:";
            // 
            // textBox_mngScoreSubjectId
            // 
            this.textBox_mngScoreSubjectId.Location = new System.Drawing.Point(163, 21);
            this.textBox_mngScoreSubjectId.Name = "textBox_mngScoreSubjectId";
            this.textBox_mngScoreSubjectId.Size = new System.Drawing.Size(147, 27);
            this.textBox_mngScoreSubjectId.TabIndex = 68;
            // 
            // label_mngScoreSubjectID
            // 
            this.label_mngScoreSubjectID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngScoreSubjectID.AutoSize = true;
            this.label_mngScoreSubjectID.Location = new System.Drawing.Point(65, 24);
            this.label_mngScoreSubjectID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_mngScoreSubjectID.Name = "label_mngScoreSubjectID";
            this.label_mngScoreSubjectID.Size = new System.Drawing.Size(75, 19);
            this.label_mngScoreSubjectID.TabIndex = 67;
            this.label_mngScoreSubjectID.Text = "Score ID:";
            // 
            // comboBox_mngScoreSubjectName
            // 
            this.comboBox_mngScoreSubjectName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_mngScoreSubjectName.FormattingEnabled = true;
            this.comboBox_mngScoreSubjectName.Location = new System.Drawing.Point(163, 97);
            this.comboBox_mngScoreSubjectName.Name = "comboBox_mngScoreSubjectName";
            this.comboBox_mngScoreSubjectName.Size = new System.Drawing.Size(220, 27);
            this.comboBox_mngScoreSubjectName.TabIndex = 66;
            // 
            // label_mngScoreSubName
            // 
            this.label_mngScoreSubName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngScoreSubName.AutoSize = true;
            this.label_mngScoreSubName.Location = new System.Drawing.Point(51, 97);
            this.label_mngScoreSubName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_mngScoreSubName.Name = "label_mngScoreSubName";
            this.label_mngScoreSubName.Size = new System.Drawing.Size(89, 19);
            this.label_mngScoreSubName.TabIndex = 65;
            this.label_mngScoreSubName.Text = "Subject ID:";
            // 
            // comboBox_mngScoreTeacherName
            // 
            this.comboBox_mngScoreTeacherName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_mngScoreTeacherName.FormattingEnabled = true;
            this.comboBox_mngScoreTeacherName.Location = new System.Drawing.Point(164, 133);
            this.comboBox_mngScoreTeacherName.Name = "comboBox_mngScoreTeacherName";
            this.comboBox_mngScoreTeacherName.Size = new System.Drawing.Size(220, 27);
            this.comboBox_mngScoreTeacherName.TabIndex = 64;
            // 
            // label_mngScoreTeacher
            // 
            this.label_mngScoreTeacher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngScoreTeacher.AutoSize = true;
            this.label_mngScoreTeacher.Location = new System.Drawing.Point(11, 136);
            this.label_mngScoreTeacher.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_mngScoreTeacher.Name = "label_mngScoreTeacher";
            this.label_mngScoreTeacher.Size = new System.Drawing.Size(129, 19);
            this.label_mngScoreTeacher.TabIndex = 63;
            this.label_mngScoreTeacher.Text = "Teacher Name:";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(1, 357);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(881, 10);
            this.panel1.TabIndex = 33;
            // 
            // panel_manageScore
            // 
            this.panel_manageScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(161)))));
            this.panel_manageScore.Controls.Add(this.botton_mngScoreBack);
            this.panel_manageScore.Controls.Add(this.label_manageScore);
            this.panel_manageScore.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_manageScore.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold);
            this.panel_manageScore.Location = new System.Drawing.Point(0, 0);
            this.panel_manageScore.Name = "panel_manageScore";
            this.panel_manageScore.Size = new System.Drawing.Size(882, 56);
            this.panel_manageScore.TabIndex = 0;
            // 
            // botton_mngScoreBack
            // 
            this.botton_mngScoreBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.botton_mngScoreBack.BackColor = System.Drawing.Color.White;
            this.botton_mngScoreBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botton_mngScoreBack.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.botton_mngScoreBack.ForeColor = System.Drawing.Color.Black;
            this.botton_mngScoreBack.Location = new System.Drawing.Point(31, 11);
            this.botton_mngScoreBack.Name = "botton_mngScoreBack";
            this.botton_mngScoreBack.Size = new System.Drawing.Size(61, 26);
            this.botton_mngScoreBack.TabIndex = 76;
            this.botton_mngScoreBack.Text = "Back";
            this.botton_mngScoreBack.UseVisualStyleBackColor = false;
            this.botton_mngScoreBack.Click += new System.EventHandler(this.botton_mngScoreBack_Click);
            // 
            // label_manageScore
            // 
            this.label_manageScore.AutoSize = true;
            this.label_manageScore.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label_manageScore.ForeColor = System.Drawing.Color.White;
            this.label_manageScore.Location = new System.Drawing.Point(392, 11);
            this.label_manageScore.Name = "label_manageScore";
            this.label_manageScore.Size = new System.Drawing.Size(170, 26);
            this.label_manageScore.TabIndex = 0;
            this.label_manageScore.Text = "Manage Score";
            // 
            // label_assessmentTtype
            // 
            this.label_assessmentTtype.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_assessmentTtype.AutoSize = true;
            this.label_assessmentTtype.Location = new System.Drawing.Point(395, 34);
            this.label_assessmentTtype.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_assessmentTtype.Name = "label_assessmentTtype";
            this.label_assessmentTtype.Size = new System.Drawing.Size(140, 19);
            this.label_assessmentTtype.TabIndex = 76;
            this.label_assessmentTtype.Text = "Assessment Type:";
            // 
            // textBox_mngeAssessmentType
            // 
            this.textBox_mngeAssessmentType.Location = new System.Drawing.Point(542, 26);
            this.textBox_mngeAssessmentType.Name = "textBox_mngeAssessmentType";
            this.textBox_mngeAssessmentType.Size = new System.Drawing.Size(202, 27);
            this.textBox_mngeAssessmentType.TabIndex = 77;
            // 
            // ManageScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_mainmngScore);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MinimumSize = new System.Drawing.Size(900, 650);
            this.Name = "ManageScore";
            this.Text = "Manage Score";
            this.panel_mainmngScore.ResumeLayout(false);
            this.panel_mgnScrocebuttom.ResumeLayout(false);
            this.panel_mgnScrocebuttom.PerformLayout();
            this.panel_manageScore.ResumeLayout(false);
            this.panel_manageScore.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_mainmngScore;
        private System.Windows.Forms.Panel panel_manageScore;
        private System.Windows.Forms.Label label_manageScore;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_mgnScrocebuttom;
        private System.Windows.Forms.Button button_mngScoreClear;
        private System.Windows.Forms.Button button_mngScoreDelete;
        private System.Windows.Forms.Button button_mngScoreUpdate;
        private System.Windows.Forms.Label label_mngScoreStudID;
        private System.Windows.Forms.TextBox textBox_mngScoreStudentId;
        private System.Windows.Forms.TextBox textBox_mngScoreMarks;
        private System.Windows.Forms.Label label_subMarks;
        private System.Windows.Forms.TextBox textBox_mngScoreSubjectId;
        private System.Windows.Forms.Label label_mngScoreSubjectID;
        private System.Windows.Forms.ComboBox comboBox_mngScoreSubjectName;
        private System.Windows.Forms.Label label_mngScoreSubName;
        private System.Windows.Forms.ComboBox comboBox_mngScoreTeacherName;
        private System.Windows.Forms.Label label_mngScoreTeacher;
        private System.Windows.Forms.Button botton_mngScoreBack;
        private System.Windows.Forms.Label label_assessmentTtype;
        private System.Windows.Forms.TextBox textBox_mngeAssessmentType;
    }
}