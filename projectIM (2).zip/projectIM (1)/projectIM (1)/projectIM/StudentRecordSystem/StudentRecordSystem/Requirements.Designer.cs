﻿namespace StudentRecordSystem
{
    partial class Requirements
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1_reqSearchbox = new System.Windows.Forms.TextBox();
            this.button_reqSearch = new System.Windows.Forms.Button();
            this.button_ReqBack = new System.Windows.Forms.Button();
            this.label_requirements = new System.Windows.Forms.Label();
            this.panel_reqMain = new System.Windows.Forms.Panel();
            this.panel_reqbottom = new System.Windows.Forms.Panel();
            this.checkBox_req3 = new System.Windows.Forms.CheckBox();
            this.checkBox_req4 = new System.Windows.Forms.CheckBox();
            this.checkBox_req2 = new System.Windows.Forms.CheckBox();
            this.checkBox_req1 = new System.Windows.Forms.CheckBox();
            this.label_reqList = new System.Windows.Forms.Label();
            this.button_reqUpdate = new System.Windows.Forms.Button();
            this.button_reqDelete = new System.Windows.Forms.Button();
            this.textBox_mngeStudentID = new System.Windows.Forms.TextBox();
            this.label_mngeStudentID = new System.Windows.Forms.Label();
            this.button_feesAdd = new System.Windows.Forms.Button();
            this.button_redClear = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_Requirements = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label_AdmissionReqID = new System.Windows.Forms.Label();
            this.panel_reqMain.SuspendLayout();
            this.panel_reqbottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_Requirements.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1_reqSearchbox
            // 
            this.textBox1_reqSearchbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1_reqSearchbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1_reqSearchbox.Location = new System.Drawing.Point(189, 58);
            this.textBox1_reqSearchbox.Name = "textBox1_reqSearchbox";
            this.textBox1_reqSearchbox.Size = new System.Drawing.Size(173, 26);
            this.textBox1_reqSearchbox.TabIndex = 82;
            // 
            // button_reqSearch
            // 
            this.button_reqSearch.BackColor = System.Drawing.Color.DimGray;
            this.button_reqSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reqSearch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_reqSearch.ForeColor = System.Drawing.Color.White;
            this.button_reqSearch.Location = new System.Drawing.Point(94, 57);
            this.button_reqSearch.Margin = new System.Windows.Forms.Padding(5);
            this.button_reqSearch.Name = "button_reqSearch";
            this.button_reqSearch.Size = new System.Drawing.Size(87, 27);
            this.button_reqSearch.TabIndex = 81;
            this.button_reqSearch.Text = "Search";
            this.button_reqSearch.UseVisualStyleBackColor = false;
            // 
            // button_ReqBack
            // 
            this.button_ReqBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_ReqBack.BackColor = System.Drawing.Color.White;
            this.button_ReqBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReqBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReqBack.ForeColor = System.Drawing.Color.Black;
            this.button_ReqBack.Location = new System.Drawing.Point(24, 9);
            this.button_ReqBack.Margin = new System.Windows.Forms.Padding(5);
            this.button_ReqBack.Name = "button_ReqBack";
            this.button_ReqBack.Size = new System.Drawing.Size(60, 29);
            this.button_ReqBack.TabIndex = 47;
            this.button_ReqBack.Text = "Back";
            this.button_ReqBack.UseVisualStyleBackColor = false;
            this.button_ReqBack.Click += new System.EventHandler(this.button_ReqBack_Click);
            // 
            // label_requirements
            // 
            this.label_requirements.AutoSize = true;
            this.label_requirements.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_requirements.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_requirements.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_requirements.Location = new System.Drawing.Point(362, 10);
            this.label_requirements.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_requirements.Name = "label_requirements";
            this.label_requirements.Size = new System.Drawing.Size(260, 25);
            this.label_requirements.TabIndex = 0;
            this.label_requirements.Text = "Admission Requirements";
            this.label_requirements.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel_reqMain
            // 
            this.panel_reqMain.Controls.Add(this.textBox1_reqSearchbox);
            this.panel_reqMain.Controls.Add(this.button_reqSearch);
            this.panel_reqMain.Controls.Add(this.panel_reqbottom);
            this.panel_reqMain.Controls.Add(this.dataGridView1);
            this.panel_reqMain.Controls.Add(this.panel1);
            this.panel_reqMain.Controls.Add(this.panel_subBorder);
            this.panel_reqMain.Controls.Add(this.panel_Requirements);
            this.panel_reqMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_reqMain.Location = new System.Drawing.Point(0, 0);
            this.panel_reqMain.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_reqMain.Name = "panel_reqMain";
            this.panel_reqMain.Size = new System.Drawing.Size(884, 611);
            this.panel_reqMain.TabIndex = 4;
            // 
            // panel_reqbottom
            // 
            this.panel_reqbottom.Controls.Add(this.textBox1);
            this.panel_reqbottom.Controls.Add(this.label_AdmissionReqID);
            this.panel_reqbottom.Controls.Add(this.checkBox_req3);
            this.panel_reqbottom.Controls.Add(this.checkBox_req4);
            this.panel_reqbottom.Controls.Add(this.checkBox_req2);
            this.panel_reqbottom.Controls.Add(this.checkBox_req1);
            this.panel_reqbottom.Controls.Add(this.label_reqList);
            this.panel_reqbottom.Controls.Add(this.button_reqUpdate);
            this.panel_reqbottom.Controls.Add(this.button_reqDelete);
            this.panel_reqbottom.Controls.Add(this.textBox_mngeStudentID);
            this.panel_reqbottom.Controls.Add(this.label_mngeStudentID);
            this.panel_reqbottom.Controls.Add(this.button_feesAdd);
            this.panel_reqbottom.Controls.Add(this.button_redClear);
            this.panel_reqbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_reqbottom.Location = new System.Drawing.Point(0, 448);
            this.panel_reqbottom.Margin = new System.Windows.Forms.Padding(5);
            this.panel_reqbottom.Name = "panel_reqbottom";
            this.panel_reqbottom.Size = new System.Drawing.Size(884, 163);
            this.panel_reqbottom.TabIndex = 33;
            // 
            // checkBox_req3
            // 
            this.checkBox_req3.AutoSize = true;
            this.checkBox_req3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_req3.Location = new System.Drawing.Point(189, 96);
            this.checkBox_req3.Name = "checkBox_req3";
            this.checkBox_req3.Size = new System.Drawing.Size(283, 20);
            this.checkBox_req3.TabIndex = 86;
            this.checkBox_req3.Text = "GOOD MORAL CHARACTER CERTIFICATE";
            this.checkBox_req3.UseVisualStyleBackColor = true;
            // 
            // checkBox_req4
            // 
            this.checkBox_req4.AutoSize = true;
            this.checkBox_req4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_req4.Location = new System.Drawing.Point(189, 123);
            this.checkBox_req4.Name = "checkBox_req4";
            this.checkBox_req4.Size = new System.Drawing.Size(209, 20);
            this.checkBox_req4.TabIndex = 85;
            this.checkBox_req4.Text = "FOUR COPIES OF 1x1 PICTURE";
            this.checkBox_req4.UseVisualStyleBackColor = true;
            // 
            // checkBox_req2
            // 
            this.checkBox_req2.AutoSize = true;
            this.checkBox_req2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_req2.Location = new System.Drawing.Point(451, 69);
            this.checkBox_req2.Name = "checkBox_req2";
            this.checkBox_req2.Size = new System.Drawing.Size(190, 20);
            this.checkBox_req2.TabIndex = 84;
            this.checkBox_req2.Text = "FORM 138 (REPORT CARD)";
            this.checkBox_req2.UseVisualStyleBackColor = true;
            // 
            // checkBox_req1
            // 
            this.checkBox_req1.AutoSize = true;
            this.checkBox_req1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_req1.Location = new System.Drawing.Point(189, 68);
            this.checkBox_req1.Name = "checkBox_req1";
            this.checkBox_req1.Size = new System.Drawing.Size(220, 20);
            this.checkBox_req1.TabIndex = 83;
            this.checkBox_req1.Text = "PSA/LOCAL BIRTH CERTIFICATE";
            this.checkBox_req1.UseVisualStyleBackColor = true;
            // 
            // label_reqList
            // 
            this.label_reqList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_reqList.AutoSize = true;
            this.label_reqList.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_reqList.Location = new System.Drawing.Point(20, 66);
            this.label_reqList.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_reqList.Name = "label_reqList";
            this.label_reqList.Size = new System.Drawing.Size(143, 19);
            this.label_reqList.TabIndex = 82;
            this.label_reqList.Text = "Requirements List:";
            // 
            // button_reqUpdate
            // 
            this.button_reqUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_reqUpdate.BackColor = System.Drawing.Color.DarkRed;
            this.button_reqUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reqUpdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_reqUpdate.ForeColor = System.Drawing.Color.White;
            this.button_reqUpdate.Location = new System.Drawing.Point(786, 106);
            this.button_reqUpdate.Margin = new System.Windows.Forms.Padding(5);
            this.button_reqUpdate.Name = "button_reqUpdate";
            this.button_reqUpdate.Size = new System.Drawing.Size(82, 30);
            this.button_reqUpdate.TabIndex = 81;
            this.button_reqUpdate.Text = "Update";
            this.button_reqUpdate.UseVisualStyleBackColor = false;
            // 
            // button_reqDelete
            // 
            this.button_reqDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_reqDelete.BackColor = System.Drawing.Color.Red;
            this.button_reqDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reqDelete.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_reqDelete.ForeColor = System.Drawing.Color.White;
            this.button_reqDelete.Location = new System.Drawing.Point(788, 66);
            this.button_reqDelete.Margin = new System.Windows.Forms.Padding(5);
            this.button_reqDelete.Name = "button_reqDelete";
            this.button_reqDelete.Size = new System.Drawing.Size(82, 30);
            this.button_reqDelete.TabIndex = 80;
            this.button_reqDelete.Text = "Delete";
            this.button_reqDelete.UseVisualStyleBackColor = false;
            // 
            // textBox_mngeStudentID
            // 
            this.textBox_mngeStudentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mngeStudentID.Location = new System.Drawing.Point(169, 20);
            this.textBox_mngeStudentID.Name = "textBox_mngeStudentID";
            this.textBox_mngeStudentID.Size = new System.Drawing.Size(170, 26);
            this.textBox_mngeStudentID.TabIndex = 72;
            // 
            // label_mngeStudentID
            // 
            this.label_mngeStudentID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngeStudentID.AutoSize = true;
            this.label_mngeStudentID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mngeStudentID.Location = new System.Drawing.Point(70, 23);
            this.label_mngeStudentID.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_mngeStudentID.Name = "label_mngeStudentID";
            this.label_mngeStudentID.Size = new System.Drawing.Size(89, 19);
            this.label_mngeStudentID.TabIndex = 68;
            this.label_mngeStudentID.Text = "Student ID:";
            // 
            // button_feesAdd
            // 
            this.button_feesAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_feesAdd.BackColor = System.Drawing.Color.Green;
            this.button_feesAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_feesAdd.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_feesAdd.ForeColor = System.Drawing.Color.White;
            this.button_feesAdd.Location = new System.Drawing.Point(705, 106);
            this.button_feesAdd.Margin = new System.Windows.Forms.Padding(5);
            this.button_feesAdd.Name = "button_feesAdd";
            this.button_feesAdd.Size = new System.Drawing.Size(71, 30);
            this.button_feesAdd.TabIndex = 53;
            this.button_feesAdd.Text = "Add";
            this.button_feesAdd.UseVisualStyleBackColor = false;
            // 
            // button_redClear
            // 
            this.button_redClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_redClear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_redClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_redClear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_redClear.ForeColor = System.Drawing.Color.White;
            this.button_redClear.Location = new System.Drawing.Point(705, 66);
            this.button_redClear.Margin = new System.Windows.Forms.Padding(5);
            this.button_redClear.Name = "button_redClear";
            this.button_redClear.Size = new System.Drawing.Size(71, 30);
            this.button_redClear.TabIndex = 52;
            this.button_redClear.Text = "Clear";
            this.button_redClear.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 94);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(856, 333);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(0, 437);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 12);
            this.panel1.TabIndex = 31;
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 982);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 31);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_Requirements
            // 
            this.panel_Requirements.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_Requirements.Controls.Add(this.button_ReqBack);
            this.panel_Requirements.Controls.Add(this.label_requirements);
            this.panel_Requirements.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Requirements.Location = new System.Drawing.Point(0, 0);
            this.panel_Requirements.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_Requirements.Name = "panel_Requirements";
            this.panel_Requirements.Size = new System.Drawing.Size(884, 51);
            this.panel_Requirements.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(573, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(170, 26);
            this.textBox1.TabIndex = 88;
            // 
            // label_AdmissionReqID
            // 
            this.label_AdmissionReqID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_AdmissionReqID.AutoSize = true;
            this.label_AdmissionReqID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AdmissionReqID.Location = new System.Drawing.Point(414, 27);
            this.label_AdmissionReqID.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_AdmissionReqID.Name = "label_AdmissionReqID";
            this.label_AdmissionReqID.Size = new System.Drawing.Size(149, 19);
            this.label_AdmissionReqID.TabIndex = 87;
            this.label_AdmissionReqID.Text = "Admission Req. ID:";
            // 
            // Requirements
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_reqMain);
            this.Name = "Requirements";
            this.Text = "Requirements";
            this.panel_reqMain.ResumeLayout(false);
            this.panel_reqMain.PerformLayout();
            this.panel_reqbottom.ResumeLayout(false);
            this.panel_reqbottom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_Requirements.ResumeLayout(false);
            this.panel_Requirements.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1_reqSearchbox;
        private System.Windows.Forms.Button button_reqSearch;
        private System.Windows.Forms.Button button_ReqBack;
        private System.Windows.Forms.Label label_requirements;
        private System.Windows.Forms.Panel panel_reqMain;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_Requirements;
        private System.Windows.Forms.Panel panel_reqbottom;
        private System.Windows.Forms.Button button_reqUpdate;
        private System.Windows.Forms.Button button_reqDelete;
        private System.Windows.Forms.TextBox textBox_mngeStudentID;
        private System.Windows.Forms.Label label_mngeStudentID;
        private System.Windows.Forms.Button button_feesAdd;
        private System.Windows.Forms.Button button_redClear;
        private System.Windows.Forms.CheckBox checkBox_req1;
        private System.Windows.Forms.Label label_reqList;
        private System.Windows.Forms.CheckBox checkBox_req3;
        private System.Windows.Forms.CheckBox checkBox_req4;
        private System.Windows.Forms.CheckBox checkBox_req2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label_AdmissionReqID;
    }
}