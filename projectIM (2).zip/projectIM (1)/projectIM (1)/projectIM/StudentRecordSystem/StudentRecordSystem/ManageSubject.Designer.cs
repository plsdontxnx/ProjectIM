﻿namespace StudentRecordSystem
{
    partial class ManageSubject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_manageSub = new System.Windows.Forms.Panel();
            this.button_managesubBack = new System.Windows.Forms.Button();
            this.label_manageSubject = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_managesubInfo = new System.Windows.Forms.Panel();
            this.comboBox_marks = new System.Windows.Forms.ComboBox();
            this.button_subjectClear = new System.Windows.Forms.Button();
            this.button_subjectDelete = new System.Windows.Forms.Button();
            this.button_subjectUpdate = new System.Windows.Forms.Button();
            this.label_subStudentId = new System.Windows.Forms.Label();
            this.textBox_substudentId = new System.Windows.Forms.TextBox();
            this.label_subMarks = new System.Windows.Forms.Label();
            this.textBox_subjectId = new System.Windows.Forms.TextBox();
            this.label_subjectID = new System.Windows.Forms.Label();
            this.comboBox_subjectName = new System.Windows.Forms.ComboBox();
            this.label_subNameList = new System.Windows.Forms.Label();
            this.comboBox_teacherName = new System.Windows.Forms.ComboBox();
            this.label_subNameTeacher = new System.Windows.Forms.Label();
            this.panel_mainManageSub = new System.Windows.Forms.Panel();
            this.panel_manageSub.SuspendLayout();
            this.panel_managesubInfo.SuspendLayout();
            this.panel_mainManageSub.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_manageSub
            // 
            this.panel_manageSub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(161)))));
            this.panel_manageSub.Controls.Add(this.button_managesubBack);
            this.panel_manageSub.Controls.Add(this.label_manageSubject);
            this.panel_manageSub.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_manageSub.Location = new System.Drawing.Point(0, 0);
            this.panel_manageSub.Name = "panel_manageSub";
            this.panel_manageSub.Size = new System.Drawing.Size(884, 47);
            this.panel_manageSub.TabIndex = 0;
            // 
            // button_managesubBack
            // 
            this.button_managesubBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_managesubBack.BackColor = System.Drawing.Color.White;
            this.button_managesubBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_managesubBack.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.button_managesubBack.ForeColor = System.Drawing.Color.Black;
            this.button_managesubBack.Location = new System.Drawing.Point(26, 11);
            this.button_managesubBack.Name = "button_managesubBack";
            this.button_managesubBack.Size = new System.Drawing.Size(56, 24);
            this.button_managesubBack.TabIndex = 50;
            this.button_managesubBack.Text = "Back";
            this.button_managesubBack.UseVisualStyleBackColor = false;
            this.button_managesubBack.Click += new System.EventHandler(this.button_managesubBack_Click);
            // 
            // label_manageSubject
            // 
            this.label_manageSubject.AutoSize = true;
            this.label_manageSubject.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label_manageSubject.Location = new System.Drawing.Point(413, 11);
            this.label_manageSubject.Name = "label_manageSubject";
            this.label_manageSubject.Size = new System.Drawing.Size(190, 26);
            this.label_manageSubject.TabIndex = 0;
            this.label_manageSubject.Text = "Manage Subject";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(0, 348);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(881, 10);
            this.panel1.TabIndex = 32;
            // 
            // panel_managesubInfo
            // 
            this.panel_managesubInfo.Controls.Add(this.comboBox_marks);
            this.panel_managesubInfo.Controls.Add(this.button_subjectClear);
            this.panel_managesubInfo.Controls.Add(this.button_subjectDelete);
            this.panel_managesubInfo.Controls.Add(this.button_subjectUpdate);
            this.panel_managesubInfo.Controls.Add(this.label_subStudentId);
            this.panel_managesubInfo.Controls.Add(this.textBox_substudentId);
            this.panel_managesubInfo.Controls.Add(this.label_subMarks);
            this.panel_managesubInfo.Controls.Add(this.textBox_subjectId);
            this.panel_managesubInfo.Controls.Add(this.label_subjectID);
            this.panel_managesubInfo.Controls.Add(this.comboBox_subjectName);
            this.panel_managesubInfo.Controls.Add(this.label_subNameList);
            this.panel_managesubInfo.Controls.Add(this.comboBox_teacherName);
            this.panel_managesubInfo.Controls.Add(this.label_subNameTeacher);
            this.panel_managesubInfo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_managesubInfo.Location = new System.Drawing.Point(0, 361);
            this.panel_managesubInfo.Name = "panel_managesubInfo";
            this.panel_managesubInfo.Size = new System.Drawing.Size(884, 250);
            this.panel_managesubInfo.TabIndex = 33;
            // 
            // comboBox_marks
            // 
            this.comboBox_marks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_marks.FormattingEnabled = true;
            this.comboBox_marks.Location = new System.Drawing.Point(164, 176);
            this.comboBox_marks.Name = "comboBox_marks";
            this.comboBox_marks.Size = new System.Drawing.Size(174, 27);
            this.comboBox_marks.TabIndex = 63;
            // 
            // button_subjectClear
            // 
            this.button_subjectClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_subjectClear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_subjectClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_subjectClear.ForeColor = System.Drawing.Color.White;
            this.button_subjectClear.Location = new System.Drawing.Point(563, 192);
            this.button_subjectClear.Name = "button_subjectClear";
            this.button_subjectClear.Size = new System.Drawing.Size(96, 31);
            this.button_subjectClear.TabIndex = 62;
            this.button_subjectClear.Text = "Clear";
            this.button_subjectClear.UseVisualStyleBackColor = false;
            // 
            // button_subjectDelete
            // 
            this.button_subjectDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_subjectDelete.BackColor = System.Drawing.Color.Green;
            this.button_subjectDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_subjectDelete.ForeColor = System.Drawing.Color.White;
            this.button_subjectDelete.Location = new System.Drawing.Point(767, 192);
            this.button_subjectDelete.Name = "button_subjectDelete";
            this.button_subjectDelete.Size = new System.Drawing.Size(96, 31);
            this.button_subjectDelete.TabIndex = 61;
            this.button_subjectDelete.Text = "Delete";
            this.button_subjectDelete.UseVisualStyleBackColor = false;
            // 
            // button_subjectUpdate
            // 
            this.button_subjectUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_subjectUpdate.BackColor = System.Drawing.Color.Red;
            this.button_subjectUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_subjectUpdate.ForeColor = System.Drawing.Color.White;
            this.button_subjectUpdate.Location = new System.Drawing.Point(665, 192);
            this.button_subjectUpdate.Name = "button_subjectUpdate";
            this.button_subjectUpdate.Size = new System.Drawing.Size(96, 31);
            this.button_subjectUpdate.TabIndex = 60;
            this.button_subjectUpdate.Text = "Update";
            this.button_subjectUpdate.UseVisualStyleBackColor = false;
            // 
            // label_subStudentId
            // 
            this.label_subStudentId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subStudentId.AutoSize = true;
            this.label_subStudentId.Location = new System.Drawing.Point(66, 66);
            this.label_subStudentId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subStudentId.Name = "label_subStudentId";
            this.label_subStudentId.Size = new System.Drawing.Size(83, 19);
            this.label_subStudentId.TabIndex = 59;
            this.label_subStudentId.Text = "studentID:";
            // 
            // textBox_substudentId
            // 
            this.textBox_substudentId.Location = new System.Drawing.Point(164, 66);
            this.textBox_substudentId.Name = "textBox_substudentId";
            this.textBox_substudentId.Size = new System.Drawing.Size(147, 27);
            this.textBox_substudentId.TabIndex = 58;
            // 
            // label_subMarks
            // 
            this.label_subMarks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subMarks.AutoSize = true;
            this.label_subMarks.Location = new System.Drawing.Point(93, 176);
            this.label_subMarks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subMarks.Name = "label_subMarks";
            this.label_subMarks.Size = new System.Drawing.Size(58, 19);
            this.label_subMarks.TabIndex = 56;
            this.label_subMarks.Text = "Marks:";
            // 
            // textBox_subjectId
            // 
            this.textBox_subjectId.Location = new System.Drawing.Point(164, 28);
            this.textBox_subjectId.Name = "textBox_subjectId";
            this.textBox_subjectId.Size = new System.Drawing.Size(147, 27);
            this.textBox_subjectId.TabIndex = 55;
            // 
            // label_subjectID
            // 
            this.label_subjectID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subjectID.AutoSize = true;
            this.label_subjectID.Location = new System.Drawing.Point(66, 31);
            this.label_subjectID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subjectID.Name = "label_subjectID";
            this.label_subjectID.Size = new System.Drawing.Size(85, 19);
            this.label_subjectID.TabIndex = 54;
            this.label_subjectID.Text = "SubjectID:";
            // 
            // comboBox_subjectName
            // 
            this.comboBox_subjectName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_subjectName.FormattingEnabled = true;
            this.comboBox_subjectName.Location = new System.Drawing.Point(164, 99);
            this.comboBox_subjectName.Name = "comboBox_subjectName";
            this.comboBox_subjectName.Size = new System.Drawing.Size(174, 27);
            this.comboBox_subjectName.TabIndex = 53;
            // 
            // label_subNameList
            // 
            this.label_subNameList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subNameList.AutoSize = true;
            this.label_subNameList.Location = new System.Drawing.Point(28, 99);
            this.label_subNameList.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subNameList.Name = "label_subNameList";
            this.label_subNameList.Size = new System.Drawing.Size(123, 19);
            this.label_subNameList.TabIndex = 52;
            this.label_subNameList.Text = "Subject Name:";
            // 
            // comboBox_teacherName
            // 
            this.comboBox_teacherName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_teacherName.FormattingEnabled = true;
            this.comboBox_teacherName.Location = new System.Drawing.Point(164, 140);
            this.comboBox_teacherName.Name = "comboBox_teacherName";
            this.comboBox_teacherName.Size = new System.Drawing.Size(174, 27);
            this.comboBox_teacherName.TabIndex = 51;
            // 
            // label_subNameTeacher
            // 
            this.label_subNameTeacher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subNameTeacher.AutoSize = true;
            this.label_subNameTeacher.Location = new System.Drawing.Point(22, 143);
            this.label_subNameTeacher.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subNameTeacher.Name = "label_subNameTeacher";
            this.label_subNameTeacher.Size = new System.Drawing.Size(129, 19);
            this.label_subNameTeacher.TabIndex = 50;
            this.label_subNameTeacher.Text = "Teacher Name:";
            // 
            // panel_mainManageSub
            // 
            this.panel_mainManageSub.Controls.Add(this.panel_managesubInfo);
            this.panel_mainManageSub.Controls.Add(this.panel1);
            this.panel_mainManageSub.Controls.Add(this.panel_manageSub);
            this.panel_mainManageSub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_mainManageSub.Location = new System.Drawing.Point(0, 0);
            this.panel_mainManageSub.Name = "panel_mainManageSub";
            this.panel_mainManageSub.Size = new System.Drawing.Size(884, 611);
            this.panel_mainManageSub.TabIndex = 0;
            // 
            // ManageSubject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_mainManageSub);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ManageSubject";
            this.Text = "   Manage Subject";
            this.panel_manageSub.ResumeLayout(false);
            this.panel_manageSub.PerformLayout();
            this.panel_managesubInfo.ResumeLayout(false);
            this.panel_managesubInfo.PerformLayout();
            this.panel_mainManageSub.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_manageSub;
        private System.Windows.Forms.Button button_managesubBack;
        private System.Windows.Forms.Label label_manageSubject;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_managesubInfo;
        private System.Windows.Forms.Button button_subjectClear;
        private System.Windows.Forms.Button button_subjectDelete;
        private System.Windows.Forms.Button button_subjectUpdate;
        private System.Windows.Forms.Label label_subStudentId;
        private System.Windows.Forms.TextBox textBox_substudentId;
        private System.Windows.Forms.Label label_subMarks;
        private System.Windows.Forms.TextBox textBox_subjectId;
        private System.Windows.Forms.Label label_subjectID;
        private System.Windows.Forms.ComboBox comboBox_subjectName;
        private System.Windows.Forms.Label label_subNameList;
        private System.Windows.Forms.ComboBox comboBox_teacherName;
        private System.Windows.Forms.Label label_subNameTeacher;
        private System.Windows.Forms.Panel panel_mainManageSub;
        private System.Windows.Forms.ComboBox comboBox_marks;
    }
}