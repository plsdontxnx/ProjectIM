﻿using System;
using System.Windows.Forms;

namespace StudentRecordSystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            customizeDesign();

        }
        private void MainForm_load(object sender, EventArgs e)
        {

        }
        private void customizeDesign()
        {
            panel_studSubmenu.Visible = false;
            panel_subjectSubmenu.Visible = false;
            panel_scoreSubmenu.Visible = false;
            panel_enrollSubmenu.Visible = false;
            panel_requirementSubmenu.Visible = false;
        }
        private void hideSubmenu()
        {
            if (panel_studSubmenu.Visible == true)
                panel_studSubmenu.Visible = false;

            if (panel_subjectSubmenu.Visible == true)
                panel_subjectSubmenu.Visible = false;

            if (panel_scoreSubmenu.Visible == true)
                panel_scoreSubmenu.Visible = false;

            if (panel_enrollSubmenu.Visible == true)
                panel_enrollSubmenu.Visible = false;

            if (panel_requirementSubmenu.Visible == true)
                panel_requirementSubmenu.Visible = false;
        }
        private void showSubmenu(Panel Submenu)
        {
            if (Submenu.Visible == false)
            {
                hideSubmenu();
                Submenu.Visible = true;
            }
            else
                Submenu.Visible = false;
        }

        private void button_student_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_studSubmenu);
        }
        #region studSubmenu 
        private void button_registration_Click(object sender, EventArgs e)
        {
            registrationForm registrationForm = new registrationForm();
            registrationForm.Show();
            this.Hide();
            hideSubmenu();
        }

        private void button_enrolledStud_Click(object sender, EventArgs e)
        {
            EnrolledStudent enrolledstud  = new EnrolledStudent();
            enrolledstud.Show();
            this.Hide();
            hideSubmenu();
        }

        private void button_stdPrint_Click(object sender, EventArgs e)
        {
            PrintStudent printStudent = new PrintStudent();
            printStudent.Show();
            this.Hide();
            hideSubmenu();
        }
        #endregion studSubmenu
        private void button_subject_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_subjectSubmenu);
        }
        #region subjectSubmenu
        private void button_subjectName_Click(object sender, EventArgs e)
        {
            SubjectName subjectName = new SubjectName();
            subjectName.Show();
            this.Hide();
            hideSubmenu();
        }

        private void button_manageSub_Click(object sender, EventArgs e)
        {
            ManageSubject manageSub = new ManageSubject();
            manageSub.Show();
            this.Hide();
            hideSubmenu();
        }

        private void button_subjectPrint_Click(object sender, EventArgs e)
        {
            PrintSubjectList printsublist = new PrintSubjectList();
            printsublist.Show();
            this.Hide();
            hideSubmenu();
        }
        #endregion subjectSubmenu
        private void button_score_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_scoreSubmenu);
        }

        #region scoreSubmenu
        private void button_newScore_Click(object sender, EventArgs e)
        {
            NewScore newScore = new NewScore();
            newScore.Show();
            this.Hide();  
            hideSubmenu();
        }

        private void button_manageScore_Click(object sender, EventArgs e)
        {
            ManageScore manageScore = new ManageScore();
            manageScore.Show();
            this.Hide();
            hideSubmenu();
        }

        private void button_scorePrint_Click(object sender, EventArgs e)
        {
           PrintScore printScore = new PrintScore();
            printScore.Show();
            this.Hide();
            hideSubmenu();
        }
        #endregion scoreSubmenu
        private void button_enrollmentrates_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_enrollSubmenu);
        }
        #region enrollSubmenu
        private void button_enrollFees_Click(object sender, EventArgs e)
        {
            Fees fees = new Fees();
            fees.Show();
            this.Hide();
            hideSubmenu();
        }
        private void button_enrollManageFees_Click(object sender, EventArgs e)
        {
            ManageFees Manage = new ManageFees();
            Manage.Show();
            this.Hide();
            hideSubmenu();

        }

        private void button_enrollPrint_Click(object sender, EventArgs e)
        {
            PrintEnrollmentRates printEnrollmentRates = new PrintEnrollmentRates();
            printEnrollmentRates.Show();
            this.Hide();
            hideSubmenu();
        }
        #endregion enrollSubmenu
        private void button_admissionReq_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_requirementSubmenu);
        }
        #region requirementSubmenu
        private void button_Req_Click(object sender, EventArgs e)
        {
            Requirements reqs = new Requirements();
            reqs.Show();
            this.Hide();
            hideSubmenu();
        }

        private void button_requirementPrint_Click(object sender, EventArgs e)
        {
           RequirementsPrint reqs = new RequirementsPrint();
            reqs.Show();
            this.Hide();
            hideSubmenu();
        }

        #endregion requirementSubmenu
    }
 }

