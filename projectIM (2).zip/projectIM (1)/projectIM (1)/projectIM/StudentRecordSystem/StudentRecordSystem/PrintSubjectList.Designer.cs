﻿namespace StudentRecordSystem
{
    partial class PrintSubjectList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_submainPrintSub = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_subListbuttonpanel = new System.Windows.Forms.Panel();
            this.button_subListPrint = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_subListSearch = new System.Windows.Forms.TextBox();
            this.label_subListSearch = new System.Windows.Forms.Label();
            this.panel_printSubList = new System.Windows.Forms.Panel();
            this.button_printSubListBack = new System.Windows.Forms.Button();
            this.label_printSubList = new System.Windows.Forms.Label();
            this.panel_submainPrintSub.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_subListbuttonpanel.SuspendLayout();
            this.panel_printSubList.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_submainPrintSub
            // 
            this.panel_submainPrintSub.Controls.Add(this.dataGridView1);
            this.panel_submainPrintSub.Controls.Add(this.panel_subListbuttonpanel);
            this.panel_submainPrintSub.Controls.Add(this.panel1);
            this.panel_submainPrintSub.Controls.Add(this.textBox_subListSearch);
            this.panel_submainPrintSub.Controls.Add(this.label_subListSearch);
            this.panel_submainPrintSub.Controls.Add(this.panel_printSubList);
            this.panel_submainPrintSub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_submainPrintSub.Location = new System.Drawing.Point(0, 0);
            this.panel_submainPrintSub.Name = "panel_submainPrintSub";
            this.panel_submainPrintSub.Size = new System.Drawing.Size(884, 611);
            this.panel_submainPrintSub.TabIndex = 0;
            this.panel_submainPrintSub.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_submainPrintSub_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 145);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(884, 359);
            this.dataGridView1.TabIndex = 5;
            // 
            // panel_subListbuttonpanel
            // 
            this.panel_subListbuttonpanel.Controls.Add(this.button_subListPrint);
            this.panel_subListbuttonpanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_subListbuttonpanel.Location = new System.Drawing.Point(0, 529);
            this.panel_subListbuttonpanel.Name = "panel_subListbuttonpanel";
            this.panel_subListbuttonpanel.Size = new System.Drawing.Size(884, 82);
            this.panel_subListbuttonpanel.TabIndex = 4;
            // 
            // button_subListPrint
            // 
            this.button_subListPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.button_subListPrint.Location = new System.Drawing.Point(773, 18);
            this.button_subListPrint.Name = "button_subListPrint";
            this.button_subListPrint.Size = new System.Drawing.Size(80, 43);
            this.button_subListPrint.TabIndex = 0;
            this.button_subListPrint.Text = "Print";
            this.button_subListPrint.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(-16, 510);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(905, 13);
            this.panel1.TabIndex = 3;
            // 
            // textBox_subListSearch
            // 
            this.textBox_subListSearch.Location = new System.Drawing.Point(120, 112);
            this.textBox_subListSearch.Name = "textBox_subListSearch";
            this.textBox_subListSearch.Size = new System.Drawing.Size(177, 27);
            this.textBox_subListSearch.TabIndex = 2;
            // 
            // label_subListSearch
            // 
            this.label_subListSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subListSearch.AutoSize = true;
            this.label_subListSearch.Location = new System.Drawing.Point(47, 115);
            this.label_subListSearch.Name = "label_subListSearch";
            this.label_subListSearch.Size = new System.Drawing.Size(67, 19);
            this.label_subListSearch.TabIndex = 1;
            this.label_subListSearch.Text = "Search:";
            // 
            // panel_printSubList
            // 
            this.panel_printSubList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_printSubList.Controls.Add(this.button_printSubListBack);
            this.panel_printSubList.Controls.Add(this.label_printSubList);
            this.panel_printSubList.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_printSubList.Location = new System.Drawing.Point(0, 0);
            this.panel_printSubList.Name = "panel_printSubList";
            this.panel_printSubList.Size = new System.Drawing.Size(884, 100);
            this.panel_printSubList.TabIndex = 0;
            // 
            // button_printSubListBack
            // 
            this.button_printSubListBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button_printSubListBack.Location = new System.Drawing.Point(23, 18);
            this.button_printSubListBack.Name = "button_printSubListBack";
            this.button_printSubListBack.Size = new System.Drawing.Size(62, 34);
            this.button_printSubListBack.TabIndex = 6;
            this.button_printSubListBack.Text = "Back";
            this.button_printSubListBack.UseVisualStyleBackColor = false;
            this.button_printSubListBack.Click += new System.EventHandler(this.button_printSubListBack_Click);
            // 
            // label_printSubList
            // 
            this.label_printSubList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_printSubList.AutoSize = true;
            this.label_printSubList.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label_printSubList.Location = new System.Drawing.Point(408, 35);
            this.label_printSubList.Name = "label_printSubList";
            this.label_printSubList.Size = new System.Drawing.Size(180, 26);
            this.label_printSubList.TabIndex = 0;
            this.label_printSubList.Text = "Print Subject List";
            // 
            // PrintSubjectList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_submainPrintSub);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(900, 650);
            this.Name = "PrintSubjectList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PrintSubjectList";
            this.panel_submainPrintSub.ResumeLayout(false);
            this.panel_submainPrintSub.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_subListbuttonpanel.ResumeLayout(false);
            this.panel_printSubList.ResumeLayout(false);
            this.panel_printSubList.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_submainPrintSub;
        private System.Windows.Forms.Panel panel_printSubList;
        private System.Windows.Forms.Label label_printSubList;
        private System.Windows.Forms.Label label_subListSearch;
        private System.Windows.Forms.Panel panel_subListbuttonpanel;
        private System.Windows.Forms.Button button_subListPrint;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_subListSearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button_printSubListBack;
    }
}