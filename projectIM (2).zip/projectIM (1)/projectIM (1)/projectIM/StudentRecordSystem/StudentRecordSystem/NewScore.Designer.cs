﻿namespace StudentRecordSystem
{
    partial class NewScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_scoreMain = new System.Windows.Forms.Panel();
            this.panel_scorebottonp = new System.Windows.Forms.Panel();
            this.label_assessment = new System.Windows.Forms.Label();
            this.dateTimePicker_scoreDate = new System.Windows.Forms.DateTimePicker();
            this.button_scoreAdd = new System.Windows.Forms.Button();
            this.button_scoreclear = new System.Windows.Forms.Button();
            this.comboBox_scoreAssessment = new System.Windows.Forms.ComboBox();
            this.label_scoreDate = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_newScore = new System.Windows.Forms.Panel();
            this.button_newScoreBack = new System.Windows.Forms.Button();
            this.label_newScore = new System.Windows.Forms.Label();
            this.panel_scoreMain.SuspendLayout();
            this.panel_scorebottonp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_newScore.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_scoreMain
            // 
            this.panel_scoreMain.Controls.Add(this.panel_scorebottonp);
            this.panel_scoreMain.Controls.Add(this.dataGridView1);
            this.panel_scoreMain.Controls.Add(this.panel1);
            this.panel_scoreMain.Controls.Add(this.panel_subBorder);
            this.panel_scoreMain.Controls.Add(this.panel_newScore);
            this.panel_scoreMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_scoreMain.Location = new System.Drawing.Point(0, 0);
            this.panel_scoreMain.Margin = new System.Windows.Forms.Padding(4);
            this.panel_scoreMain.Name = "panel_scoreMain";
            this.panel_scoreMain.Size = new System.Drawing.Size(884, 611);
            this.panel_scoreMain.TabIndex = 1;
            // 
            // panel_scorebottonp
            // 
            this.panel_scorebottonp.Controls.Add(this.label_assessment);
            this.panel_scorebottonp.Controls.Add(this.dateTimePicker_scoreDate);
            this.panel_scorebottonp.Controls.Add(this.button_scoreAdd);
            this.panel_scorebottonp.Controls.Add(this.button_scoreclear);
            this.panel_scorebottonp.Controls.Add(this.comboBox_scoreAssessment);
            this.panel_scorebottonp.Controls.Add(this.label_scoreDate);
            this.panel_scorebottonp.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_scorebottonp.Location = new System.Drawing.Point(0, 411);
            this.panel_scorebottonp.Name = "panel_scorebottonp";
            this.panel_scorebottonp.Size = new System.Drawing.Size(884, 200);
            this.panel_scorebottonp.TabIndex = 33;
            // 
            // label_assessment
            // 
            this.label_assessment.AutoSize = true;
            this.label_assessment.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_assessment.Location = new System.Drawing.Point(27, 54);
            this.label_assessment.Name = "label_assessment";
            this.label_assessment.Size = new System.Drawing.Size(144, 21);
            this.label_assessment.TabIndex = 57;
            this.label_assessment.Text = "Assessment Type:";
            // 
            // dateTimePicker_scoreDate
            // 
            this.dateTimePicker_scoreDate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_scoreDate.Location = new System.Drawing.Point(200, 88);
            this.dateTimePicker_scoreDate.Name = "dateTimePicker_scoreDate";
            this.dateTimePicker_scoreDate.Size = new System.Drawing.Size(325, 27);
            this.dateTimePicker_scoreDate.TabIndex = 56;
            // 
            // button_scoreAdd
            // 
            this.button_scoreAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_scoreAdd.BackColor = System.Drawing.Color.Green;
            this.button_scoreAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_scoreAdd.ForeColor = System.Drawing.Color.White;
            this.button_scoreAdd.Location = new System.Drawing.Point(746, 129);
            this.button_scoreAdd.Name = "button_scoreAdd";
            this.button_scoreAdd.Size = new System.Drawing.Size(96, 31);
            this.button_scoreAdd.TabIndex = 53;
            this.button_scoreAdd.Text = "Add";
            this.button_scoreAdd.UseVisualStyleBackColor = false;
            // 
            // button_scoreclear
            // 
            this.button_scoreclear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_scoreclear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_scoreclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_scoreclear.ForeColor = System.Drawing.Color.White;
            this.button_scoreclear.Location = new System.Drawing.Point(623, 129);
            this.button_scoreclear.Name = "button_scoreclear";
            this.button_scoreclear.Size = new System.Drawing.Size(96, 31);
            this.button_scoreclear.TabIndex = 52;
            this.button_scoreclear.Text = "Clear";
            this.button_scoreclear.UseVisualStyleBackColor = false;
            // 
            // comboBox_scoreAssessment
            // 
            this.comboBox_scoreAssessment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_scoreAssessment.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_scoreAssessment.FormattingEnabled = true;
            this.comboBox_scoreAssessment.Location = new System.Drawing.Point(200, 54);
            this.comboBox_scoreAssessment.Name = "comboBox_scoreAssessment";
            this.comboBox_scoreAssessment.Size = new System.Drawing.Size(220, 29);
            this.comboBox_scoreAssessment.TabIndex = 49;
            // 
            // label_scoreDate
            // 
            this.label_scoreDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_scoreDate.AutoSize = true;
            this.label_scoreDate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_scoreDate.Location = new System.Drawing.Point(118, 90);
            this.label_scoreDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_scoreDate.Name = "label_scoreDate";
            this.label_scoreDate.Size = new System.Drawing.Size(54, 21);
            this.label_scoreDate.TabIndex = 48;
            this.label_scoreDate.Text = "Date:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(860, 337);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(-3, 405);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 10);
            this.panel1.TabIndex = 31;
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 608);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(4);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 19);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_newScore
            // 
            this.panel_newScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_newScore.Controls.Add(this.button_newScoreBack);
            this.panel_newScore.Controls.Add(this.label_newScore);
            this.panel_newScore.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_newScore.Location = new System.Drawing.Point(0, 0);
            this.panel_newScore.Margin = new System.Windows.Forms.Padding(4);
            this.panel_newScore.Name = "panel_newScore";
            this.panel_newScore.Size = new System.Drawing.Size(884, 45);
            this.panel_newScore.TabIndex = 0;
            // 
            // button_newScoreBack
            // 
            this.button_newScoreBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_newScoreBack.BackColor = System.Drawing.Color.White;
            this.button_newScoreBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_newScoreBack.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.button_newScoreBack.ForeColor = System.Drawing.Color.Black;
            this.button_newScoreBack.Location = new System.Drawing.Point(31, 7);
            this.button_newScoreBack.Name = "button_newScoreBack";
            this.button_newScoreBack.Size = new System.Drawing.Size(67, 25);
            this.button_newScoreBack.TabIndex = 47;
            this.button_newScoreBack.Text = "Back";
            this.button_newScoreBack.UseVisualStyleBackColor = false;
            this.button_newScoreBack.Click += new System.EventHandler(this.button_newScoreBack_Click);
            // 
            // label_newScore
            // 
            this.label_newScore.AutoSize = true;
            this.label_newScore.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label_newScore.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_newScore.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_newScore.Location = new System.Drawing.Point(421, 9);
            this.label_newScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_newScore.Name = "label_newScore";
            this.label_newScore.Size = new System.Drawing.Size(108, 23);
            this.label_newScore.TabIndex = 0;
            this.label_newScore.Text = "New Score";
            this.label_newScore.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // NewScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_scoreMain);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MinimumSize = new System.Drawing.Size(900, 650);
            this.Name = "NewScore";
            this.Text = "NewScore";
            this.panel_scoreMain.ResumeLayout(false);
            this.panel_scorebottonp.ResumeLayout(false);
            this.panel_scorebottonp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_newScore.ResumeLayout(false);
            this.panel_newScore.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_scoreMain;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_newScore;
        private System.Windows.Forms.Button button_newScoreBack;
        private System.Windows.Forms.Label label_newScore;
        private System.Windows.Forms.Panel panel_scorebottonp;
        private System.Windows.Forms.DateTimePicker dateTimePicker_scoreDate;
        private System.Windows.Forms.Button button_scoreAdd;
        private System.Windows.Forms.Button button_scoreclear;
        private System.Windows.Forms.ComboBox comboBox_scoreAssessment;
        private System.Windows.Forms.Label label_scoreDate;
        private System.Windows.Forms.Label label_assessment;
    }
}