﻿namespace StudentRecordSystem
{
    partial class PrintEnrollmentRates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_feesPrintBack = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_feesPrintMain = new System.Windows.Forms.Panel();
            this.panel_feesPrintBottom = new System.Windows.Forms.Panel();
            this.button_feesPrint = new System.Windows.Forms.Button();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_feesPrint = new System.Windows.Forms.Panel();
            this.label_feesPrint = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_feesPrintMain.SuspendLayout();
            this.panel_feesPrintBottom.SuspendLayout();
            this.panel_feesPrint.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(0, 512);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 12);
            this.panel1.TabIndex = 31;
            // 
            // button_feesPrintBack
            // 
            this.button_feesPrintBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_feesPrintBack.BackColor = System.Drawing.Color.White;
            this.button_feesPrintBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_feesPrintBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_feesPrintBack.ForeColor = System.Drawing.Color.Black;
            this.button_feesPrintBack.Location = new System.Drawing.Point(28, 9);
            this.button_feesPrintBack.Margin = new System.Windows.Forms.Padding(5);
            this.button_feesPrintBack.Name = "button_feesPrintBack";
            this.button_feesPrintBack.Size = new System.Drawing.Size(60, 29);
            this.button_feesPrintBack.TabIndex = 47;
            this.button_feesPrintBack.Text = "Back";
            this.button_feesPrintBack.UseVisualStyleBackColor = false;
            this.button_feesPrintBack.Click += new System.EventHandler(this.button_feesPrintBack_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 62);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(856, 440);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel_feesPrintMain
            // 
            this.panel_feesPrintMain.Controls.Add(this.panel_feesPrintBottom);
            this.panel_feesPrintMain.Controls.Add(this.dataGridView1);
            this.panel_feesPrintMain.Controls.Add(this.panel1);
            this.panel_feesPrintMain.Controls.Add(this.panel_subBorder);
            this.panel_feesPrintMain.Controls.Add(this.panel_feesPrint);
            this.panel_feesPrintMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_feesPrintMain.Location = new System.Drawing.Point(0, 0);
            this.panel_feesPrintMain.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_feesPrintMain.Name = "panel_feesPrintMain";
            this.panel_feesPrintMain.Size = new System.Drawing.Size(884, 611);
            this.panel_feesPrintMain.TabIndex = 4;
            // 
            // panel_feesPrintBottom
            // 
            this.panel_feesPrintBottom.Controls.Add(this.button_feesPrint);
            this.panel_feesPrintBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_feesPrintBottom.Location = new System.Drawing.Point(0, 522);
            this.panel_feesPrintBottom.Margin = new System.Windows.Forms.Padding(5);
            this.panel_feesPrintBottom.Name = "panel_feesPrintBottom";
            this.panel_feesPrintBottom.Size = new System.Drawing.Size(884, 89);
            this.panel_feesPrintBottom.TabIndex = 33;
            // 
            // button_feesPrint
            // 
            this.button_feesPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_feesPrint.BackColor = System.Drawing.Color.Teal;
            this.button_feesPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_feesPrint.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_feesPrint.ForeColor = System.Drawing.Color.White;
            this.button_feesPrint.Location = new System.Drawing.Point(716, 26);
            this.button_feesPrint.Margin = new System.Windows.Forms.Padding(5);
            this.button_feesPrint.Name = "button_feesPrint";
            this.button_feesPrint.Size = new System.Drawing.Size(119, 39);
            this.button_feesPrint.TabIndex = 53;
            this.button_feesPrint.Text = "Print";
            this.button_feesPrint.UseVisualStyleBackColor = false;
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 982);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 31);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_feesPrint
            // 
            this.panel_feesPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_feesPrint.Controls.Add(this.button_feesPrintBack);
            this.panel_feesPrint.Controls.Add(this.label_feesPrint);
            this.panel_feesPrint.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_feesPrint.Location = new System.Drawing.Point(0, 0);
            this.panel_feesPrint.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_feesPrint.Name = "panel_feesPrint";
            this.panel_feesPrint.Size = new System.Drawing.Size(884, 51);
            this.panel_feesPrint.TabIndex = 0;
            // 
            // label_feesPrint
            // 
            this.label_feesPrint.AutoSize = true;
            this.label_feesPrint.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_feesPrint.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_feesPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_feesPrint.Location = new System.Drawing.Point(331, 13);
            this.label_feesPrint.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_feesPrint.Name = "label_feesPrint";
            this.label_feesPrint.Size = new System.Drawing.Size(227, 25);
            this.label_feesPrint.TabIndex = 0;
            this.label_feesPrint.Text = "Print Enrollment Rates";
            this.label_feesPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // PrintEnrollmentRates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_feesPrintMain);
            this.Name = "PrintEnrollmentRates";
            this.Text = "PrintEnrollmentRates";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_feesPrintMain.ResumeLayout(false);
            this.panel_feesPrintBottom.ResumeLayout(false);
            this.panel_feesPrint.ResumeLayout(false);
            this.panel_feesPrint.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_feesPrintBack;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel_feesPrintMain;
        private System.Windows.Forms.Panel panel_feesPrintBottom;
        private System.Windows.Forms.Button button_feesPrint;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_feesPrint;
        private System.Windows.Forms.Label label_feesPrint;
    }
}