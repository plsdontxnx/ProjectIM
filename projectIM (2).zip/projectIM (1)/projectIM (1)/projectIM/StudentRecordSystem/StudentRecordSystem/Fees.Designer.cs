﻿namespace StudentRecordSystem
{
    partial class Fees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_feesBack = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_feesMain = new System.Windows.Forms.Panel();
            this.panel_feesbottom = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_ratesSchoolYear = new System.Windows.Forms.TextBox();
            this.textBox_ratesStudentID = new System.Windows.Forms.TextBox();
            this.textBox_rateEnrollmentID = new System.Windows.Forms.TextBox();
            this.label_ratesSy = new System.Windows.Forms.Label();
            this.label_enrollmentID = new System.Windows.Forms.Label();
            this.button_feesAdd = new System.Windows.Forms.Button();
            this.button_feesClear = new System.Windows.Forms.Button();
            this.label_studentID = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_fees = new System.Windows.Forms.Panel();
            this.label_fees = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_feesMain.SuspendLayout();
            this.panel_feesbottom.SuspendLayout();
            this.panel_fees.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_feesBack
            // 
            this.button_feesBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_feesBack.BackColor = System.Drawing.Color.White;
            this.button_feesBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_feesBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_feesBack.ForeColor = System.Drawing.Color.Black;
            this.button_feesBack.Location = new System.Drawing.Point(28, 9);
            this.button_feesBack.Margin = new System.Windows.Forms.Padding(5);
            this.button_feesBack.Name = "button_feesBack";
            this.button_feesBack.Size = new System.Drawing.Size(60, 29);
            this.button_feesBack.TabIndex = 47;
            this.button_feesBack.Text = "Back";
            this.button_feesBack.UseVisualStyleBackColor = false;
            this.button_feesBack.Click += new System.EventHandler(this.button_feesBack_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 62);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(856, 302);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel_feesMain
            // 
            this.panel_feesMain.Controls.Add(this.panel_feesbottom);
            this.panel_feesMain.Controls.Add(this.dataGridView1);
            this.panel_feesMain.Controls.Add(this.panel1);
            this.panel_feesMain.Controls.Add(this.panel_subBorder);
            this.panel_feesMain.Controls.Add(this.panel_fees);
            this.panel_feesMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_feesMain.Location = new System.Drawing.Point(0, 0);
            this.panel_feesMain.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_feesMain.Name = "panel_feesMain";
            this.panel_feesMain.Size = new System.Drawing.Size(884, 611);
            this.panel_feesMain.TabIndex = 3;
            // 
            // panel_feesbottom
            // 
            this.panel_feesbottom.Controls.Add(this.textBox3);
            this.panel_feesbottom.Controls.Add(this.label3);
            this.panel_feesbottom.Controls.Add(this.textBox2);
            this.panel_feesbottom.Controls.Add(this.label2);
            this.panel_feesbottom.Controls.Add(this.textBox1);
            this.panel_feesbottom.Controls.Add(this.label1);
            this.panel_feesbottom.Controls.Add(this.textBox_ratesSchoolYear);
            this.panel_feesbottom.Controls.Add(this.textBox_ratesStudentID);
            this.panel_feesbottom.Controls.Add(this.textBox_rateEnrollmentID);
            this.panel_feesbottom.Controls.Add(this.label_ratesSy);
            this.panel_feesbottom.Controls.Add(this.label_enrollmentID);
            this.panel_feesbottom.Controls.Add(this.button_feesAdd);
            this.panel_feesbottom.Controls.Add(this.button_feesClear);
            this.panel_feesbottom.Controls.Add(this.label_studentID);
            this.panel_feesbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_feesbottom.Location = new System.Drawing.Point(0, 386);
            this.panel_feesbottom.Margin = new System.Windows.Forms.Padding(5);
            this.panel_feesbottom.Name = "panel_feesbottom";
            this.panel_feesbottom.Size = new System.Drawing.Size(884, 225);
            this.panel_feesbottom.TabIndex = 33;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(509, 122);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(170, 26);
            this.textBox3.TabIndex = 67;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(408, 124);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 21);
            this.label3.TabIndex = 66;
            this.label3.Text = "Total Fees:";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(509, 72);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(170, 26);
            this.textBox2.TabIndex = 65;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(401, 77);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 21);
            this.label2.TabIndex = 64;
            this.label2.Text = "Other Fees:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(509, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(170, 26);
            this.textBox1.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(434, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 21);
            this.label1.TabIndex = 62;
            this.label1.Text = "Tuition:";
            // 
            // textBox_ratesSchoolYear
            // 
            this.textBox_ratesSchoolYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ratesSchoolYear.Location = new System.Drawing.Point(151, 72);
            this.textBox_ratesSchoolYear.Name = "textBox_ratesSchoolYear";
            this.textBox_ratesSchoolYear.Size = new System.Drawing.Size(170, 26);
            this.textBox_ratesSchoolYear.TabIndex = 61;
            // 
            // textBox_ratesStudentID
            // 
            this.textBox_ratesStudentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ratesStudentID.Location = new System.Drawing.Point(149, 127);
            this.textBox_ratesStudentID.Name = "textBox_ratesStudentID";
            this.textBox_ratesStudentID.Size = new System.Drawing.Size(170, 26);
            this.textBox_ratesStudentID.TabIndex = 60;
            // 
            // textBox_rateEnrollmentID
            // 
            this.textBox_rateEnrollmentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_rateEnrollmentID.Location = new System.Drawing.Point(149, 29);
            this.textBox_rateEnrollmentID.Name = "textBox_rateEnrollmentID";
            this.textBox_rateEnrollmentID.Size = new System.Drawing.Size(170, 26);
            this.textBox_rateEnrollmentID.TabIndex = 59;
            // 
            // label_ratesSy
            // 
            this.label_ratesSy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_ratesSy.AutoSize = true;
            this.label_ratesSy.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ratesSy.Location = new System.Drawing.Point(35, 75);
            this.label_ratesSy.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_ratesSy.Name = "label_ratesSy";
            this.label_ratesSy.Size = new System.Drawing.Size(106, 21);
            this.label_ratesSy.TabIndex = 58;
            this.label_ratesSy.Text = "School Year:";
            // 
            // label_enrollmentID
            // 
            this.label_enrollmentID.AutoSize = true;
            this.label_enrollmentID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_enrollmentID.Location = new System.Drawing.Point(24, 31);
            this.label_enrollmentID.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_enrollmentID.Name = "label_enrollmentID";
            this.label_enrollmentID.Size = new System.Drawing.Size(117, 21);
            this.label_enrollmentID.TabIndex = 57;
            this.label_enrollmentID.Text = "Enrollment ID:";
            // 
            // button_feesAdd
            // 
            this.button_feesAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_feesAdd.BackColor = System.Drawing.Color.Green;
            this.button_feesAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_feesAdd.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_feesAdd.ForeColor = System.Drawing.Color.White;
            this.button_feesAdd.Location = new System.Drawing.Point(780, 172);
            this.button_feesAdd.Margin = new System.Windows.Forms.Padding(5);
            this.button_feesAdd.Name = "button_feesAdd";
            this.button_feesAdd.Size = new System.Drawing.Size(90, 39);
            this.button_feesAdd.TabIndex = 53;
            this.button_feesAdd.Text = "Add";
            this.button_feesAdd.UseVisualStyleBackColor = false;
            // 
            // button_feesClear
            // 
            this.button_feesClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_feesClear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_feesClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_feesClear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_feesClear.ForeColor = System.Drawing.Color.White;
            this.button_feesClear.Location = new System.Drawing.Point(682, 172);
            this.button_feesClear.Margin = new System.Windows.Forms.Padding(5);
            this.button_feesClear.Name = "button_feesClear";
            this.button_feesClear.Size = new System.Drawing.Size(88, 39);
            this.button_feesClear.TabIndex = 52;
            this.button_feesClear.Text = "Clear";
            this.button_feesClear.UseVisualStyleBackColor = false;
            // 
            // label_studentID
            // 
            this.label_studentID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_studentID.AutoSize = true;
            this.label_studentID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_studentID.Location = new System.Drawing.Point(41, 127);
            this.label_studentID.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_studentID.Name = "label_studentID";
            this.label_studentID.Size = new System.Drawing.Size(98, 21);
            this.label_studentID.TabIndex = 48;
            this.label_studentID.Text = "Student ID:";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(-10, 374);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(899, 12);
            this.panel1.TabIndex = 31;
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 982);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 31);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_fees
            // 
            this.panel_fees.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_fees.Controls.Add(this.button_feesBack);
            this.panel_fees.Controls.Add(this.label_fees);
            this.panel_fees.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_fees.Location = new System.Drawing.Point(0, 0);
            this.panel_fees.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_fees.Name = "panel_fees";
            this.panel_fees.Size = new System.Drawing.Size(884, 51);
            this.panel_fees.TabIndex = 0;
            // 
            // label_fees
            // 
            this.label_fees.AutoSize = true;
            this.label_fees.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fees.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_fees.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_fees.Location = new System.Drawing.Point(416, 13);
            this.label_fees.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_fees.Name = "label_fees";
            this.label_fees.Size = new System.Drawing.Size(57, 25);
            this.label_fees.TabIndex = 0;
            this.label_fees.Text = "Fees";
            this.label_fees.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Fees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_feesMain);
            this.Name = "Fees";
            this.Text = "Fees";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_feesMain.ResumeLayout(false);
            this.panel_feesbottom.ResumeLayout(false);
            this.panel_feesbottom.PerformLayout();
            this.panel_fees.ResumeLayout(false);
            this.panel_fees.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_feesBack;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel_feesMain;
        private System.Windows.Forms.Panel panel_feesbottom;
        private System.Windows.Forms.TextBox textBox_ratesSchoolYear;
        private System.Windows.Forms.TextBox textBox_ratesStudentID;
        private System.Windows.Forms.TextBox textBox_rateEnrollmentID;
        private System.Windows.Forms.Label label_ratesSy;
        private System.Windows.Forms.Label label_enrollmentID;
        private System.Windows.Forms.Button button_feesAdd;
        private System.Windows.Forms.Button button_feesClear;
        private System.Windows.Forms.Label label_studentID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_fees;
        private System.Windows.Forms.Label label_fees;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
    }
}