﻿namespace StudentRecordSystem
{
    partial class PrintScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_mainPrint = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button_subListPrint = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_subListSearch = new System.Windows.Forms.TextBox();
            this.label_subListSearch = new System.Windows.Forms.Label();
            this.panel_printScore = new System.Windows.Forms.Panel();
            this.button_printSubListBack = new System.Windows.Forms.Button();
            this.label_printScore = new System.Windows.Forms.Label();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.panel_mainPrint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_printScore.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_mainPrint
            // 
            this.panel_mainPrint.Controls.Add(this.dataGridView1);
            this.panel_mainPrint.Controls.Add(this.button_subListPrint);
            this.panel_mainPrint.Controls.Add(this.panel1);
            this.panel_mainPrint.Controls.Add(this.textBox_subListSearch);
            this.panel_mainPrint.Controls.Add(this.label_subListSearch);
            this.panel_mainPrint.Controls.Add(this.panel_printScore);
            this.panel_mainPrint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_mainPrint.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.panel_mainPrint.Location = new System.Drawing.Point(0, 0);
            this.panel_mainPrint.Name = "panel_mainPrint";
            this.panel_mainPrint.Size = new System.Drawing.Size(900, 650);
            this.panel_mainPrint.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 104);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(897, 439);
            this.dataGridView1.TabIndex = 5;
            // 
            // button_subListPrint
            // 
            this.button_subListPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.button_subListPrint.Location = new System.Drawing.Point(791, 584);
            this.button_subListPrint.Name = "button_subListPrint";
            this.button_subListPrint.Size = new System.Drawing.Size(80, 43);
            this.button_subListPrint.TabIndex = 1;
            this.button_subListPrint.Text = "Print";
            this.button_subListPrint.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(0, 549);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(905, 13);
            this.panel1.TabIndex = 4;
            // 
            // textBox_subListSearch
            // 
            this.textBox_subListSearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox_subListSearch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.textBox_subListSearch.Location = new System.Drawing.Point(113, 71);
            this.textBox_subListSearch.Name = "textBox_subListSearch";
            this.textBox_subListSearch.Size = new System.Drawing.Size(177, 27);
            this.textBox_subListSearch.TabIndex = 4;
            // 
            // label_subListSearch
            // 
            this.label_subListSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subListSearch.AutoSize = true;
            this.label_subListSearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label_subListSearch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label_subListSearch.Location = new System.Drawing.Point(40, 74);
            this.label_subListSearch.Name = "label_subListSearch";
            this.label_subListSearch.Size = new System.Drawing.Size(67, 19);
            this.label_subListSearch.TabIndex = 3;
            this.label_subListSearch.Text = "Search:";
            // 
            // panel_printScore
            // 
            this.panel_printScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_printScore.Controls.Add(this.button_printSubListBack);
            this.panel_printScore.Controls.Add(this.label_printScore);
            this.panel_printScore.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_printScore.Location = new System.Drawing.Point(0, 0);
            this.panel_printScore.Name = "panel_printScore";
            this.panel_printScore.Size = new System.Drawing.Size(900, 56);
            this.panel_printScore.TabIndex = 0;
            // 
            // button_printSubListBack
            // 
            this.button_printSubListBack.BackColor = System.Drawing.Color.White;
            this.button_printSubListBack.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.button_printSubListBack.Location = new System.Drawing.Point(44, 8);
            this.button_printSubListBack.Name = "button_printSubListBack";
            this.button_printSubListBack.Size = new System.Drawing.Size(62, 34);
            this.button_printSubListBack.TabIndex = 7;
            this.button_printSubListBack.Text = "Back";
            this.button_printSubListBack.UseVisualStyleBackColor = false;
            this.button_printSubListBack.Click += new System.EventHandler(this.button_printSubListBack_Click);
            // 
            // label_printScore
            // 
            this.label_printScore.AutoSize = true;
            this.label_printScore.Location = new System.Drawing.Point(407, 16);
            this.label_printScore.Name = "label_printScore";
            this.label_printScore.Size = new System.Drawing.Size(122, 26);
            this.label_printScore.TabIndex = 0;
            this.label_printScore.Text = "Print Score";
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // PrintScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 650);
            this.Controls.Add(this.panel_mainPrint);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(900, 650);
            this.Name = "PrintScore";
            this.Text = "PrintScore";
            this.panel_mainPrint.ResumeLayout(false);
            this.panel_mainPrint.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_printScore.ResumeLayout(false);
            this.panel_printScore.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_mainPrint;
        private System.Windows.Forms.Panel panel_printScore;
        private System.Windows.Forms.Label label_printScore;
        private System.Windows.Forms.TextBox textBox_subListSearch;
        private System.Windows.Forms.Label label_subListSearch;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_subListPrint;
        private System.Windows.Forms.Button button_printSubListBack;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}