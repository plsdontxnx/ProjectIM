﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRecordSystem
{
    public partial class EnrolledStudent : Form
    {
        public EnrolledStudent()
        {
            InitializeComponent();
        
        }

        private void button_enrollstudBack_Click(object sender, EventArgs e)
        {

            MainForm mainform = new MainForm();
            mainform.Show();
            this.Hide();
        }

        private void EnrolledStudent_Load(object sender, EventArgs e)
        {

        


        }
    }
}
