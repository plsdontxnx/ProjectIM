﻿namespace StudentRecordSystem
{
    partial class ManageFees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_mngfeesMain = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_mangefeeSearch = new System.Windows.Forms.Button();
            this.panel_mnagefeesbottom = new System.Windows.Forms.Panel();
            this.button_mngefeesDelete = new System.Windows.Forms.Button();
            this.textBox_mngeTotalfees = new System.Windows.Forms.TextBox();
            this.label_mangeTotalfees = new System.Windows.Forms.Label();
            this.textBox_mngeOtherFees = new System.Windows.Forms.TextBox();
            this.label_mngeOtherfees = new System.Windows.Forms.Label();
            this.textBox1_mngeTuition = new System.Windows.Forms.TextBox();
            this.label_mngeTuition = new System.Windows.Forms.Label();
            this.textBox_mngeSchoolYear = new System.Windows.Forms.TextBox();
            this.textBox_mngeStudentID = new System.Windows.Forms.TextBox();
            this.textBox_mngeEnrollmentID = new System.Windows.Forms.TextBox();
            this.label_mngeSchoolYear = new System.Windows.Forms.Label();
            this.label_mngeEnrollmentID = new System.Windows.Forms.Label();
            this.label_mngeStudentID = new System.Windows.Forms.Label();
            this.button_mngefeesUpdate = new System.Windows.Forms.Button();
            this.button_mngefeesClear = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_managefees = new System.Windows.Forms.Panel();
            this.button_mngfeesBack = new System.Windows.Forms.Button();
            this.label_manageFees = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_mngfeesMain.SuspendLayout();
            this.panel_mnagefeesbottom.SuspendLayout();
            this.panel_managefees.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 94);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(856, 333);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel_mngfeesMain
            // 
            this.panel_mngfeesMain.Controls.Add(this.textBox1);
            this.panel_mngfeesMain.Controls.Add(this.button_mangefeeSearch);
            this.panel_mngfeesMain.Controls.Add(this.panel_mnagefeesbottom);
            this.panel_mngfeesMain.Controls.Add(this.dataGridView1);
            this.panel_mngfeesMain.Controls.Add(this.panel1);
            this.panel_mngfeesMain.Controls.Add(this.panel_subBorder);
            this.panel_mngfeesMain.Controls.Add(this.panel_managefees);
            this.panel_mngfeesMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_mngfeesMain.Location = new System.Drawing.Point(0, 0);
            this.panel_mngfeesMain.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_mngfeesMain.Name = "panel_mngfeesMain";
            this.panel_mngfeesMain.Size = new System.Drawing.Size(884, 611);
            this.panel_mngfeesMain.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.Location = new System.Drawing.Point(189, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 27);
            this.textBox1.TabIndex = 82;
            // 
            // button_mangefeeSearch
            // 
            this.button_mangefeeSearch.BackColor = System.Drawing.Color.DimGray;
            this.button_mangefeeSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mangefeeSearch.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_mangefeeSearch.ForeColor = System.Drawing.Color.White;
            this.button_mangefeeSearch.Location = new System.Drawing.Point(94, 57);
            this.button_mangefeeSearch.Margin = new System.Windows.Forms.Padding(5);
            this.button_mangefeeSearch.Name = "button_mangefeeSearch";
            this.button_mangefeeSearch.Size = new System.Drawing.Size(87, 27);
            this.button_mangefeeSearch.TabIndex = 81;
            this.button_mangefeeSearch.Text = "Search";
            this.button_mangefeeSearch.UseVisualStyleBackColor = false;
            // 
            // panel_mnagefeesbottom
            // 
            this.panel_mnagefeesbottom.Controls.Add(this.button_mngefeesDelete);
            this.panel_mnagefeesbottom.Controls.Add(this.textBox_mngeTotalfees);
            this.panel_mnagefeesbottom.Controls.Add(this.label_mangeTotalfees);
            this.panel_mnagefeesbottom.Controls.Add(this.textBox_mngeOtherFees);
            this.panel_mnagefeesbottom.Controls.Add(this.label_mngeOtherfees);
            this.panel_mnagefeesbottom.Controls.Add(this.textBox1_mngeTuition);
            this.panel_mnagefeesbottom.Controls.Add(this.label_mngeTuition);
            this.panel_mnagefeesbottom.Controls.Add(this.textBox_mngeSchoolYear);
            this.panel_mnagefeesbottom.Controls.Add(this.textBox_mngeStudentID);
            this.panel_mnagefeesbottom.Controls.Add(this.textBox_mngeEnrollmentID);
            this.panel_mnagefeesbottom.Controls.Add(this.label_mngeSchoolYear);
            this.panel_mnagefeesbottom.Controls.Add(this.label_mngeEnrollmentID);
            this.panel_mnagefeesbottom.Controls.Add(this.label_mngeStudentID);
            this.panel_mnagefeesbottom.Controls.Add(this.button_mngefeesUpdate);
            this.panel_mnagefeesbottom.Controls.Add(this.button_mngefeesClear);
            this.panel_mnagefeesbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_mnagefeesbottom.Location = new System.Drawing.Point(0, 448);
            this.panel_mnagefeesbottom.Margin = new System.Windows.Forms.Padding(5);
            this.panel_mnagefeesbottom.Name = "panel_mnagefeesbottom";
            this.panel_mnagefeesbottom.Size = new System.Drawing.Size(884, 163);
            this.panel_mnagefeesbottom.TabIndex = 33;
            // 
            // button_mngefeesDelete
            // 
            this.button_mngefeesDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_mngefeesDelete.BackColor = System.Drawing.Color.Red;
            this.button_mngefeesDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngefeesDelete.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_mngefeesDelete.ForeColor = System.Drawing.Color.White;
            this.button_mngefeesDelete.Location = new System.Drawing.Point(750, 66);
            this.button_mngefeesDelete.Margin = new System.Windows.Forms.Padding(5);
            this.button_mngefeesDelete.Name = "button_mngefeesDelete";
            this.button_mngefeesDelete.Size = new System.Drawing.Size(73, 30);
            this.button_mngefeesDelete.TabIndex = 80;
            this.button_mngefeesDelete.Text = "Delete";
            this.button_mngefeesDelete.UseVisualStyleBackColor = false;
            // 
            // textBox_mngeTotalfees
            // 
            this.textBox_mngeTotalfees.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mngeTotalfees.Location = new System.Drawing.Point(471, 116);
            this.textBox_mngeTotalfees.Name = "textBox_mngeTotalfees";
            this.textBox_mngeTotalfees.Size = new System.Drawing.Size(170, 26);
            this.textBox_mngeTotalfees.TabIndex = 79;
            // 
            // label_mangeTotalfees
            // 
            this.label_mangeTotalfees.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mangeTotalfees.AutoSize = true;
            this.label_mangeTotalfees.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mangeTotalfees.Location = new System.Drawing.Point(370, 111);
            this.label_mangeTotalfees.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_mangeTotalfees.Name = "label_mangeTotalfees";
            this.label_mangeTotalfees.Size = new System.Drawing.Size(91, 21);
            this.label_mangeTotalfees.TabIndex = 78;
            this.label_mangeTotalfees.Text = "Total Fees:";
            // 
            // textBox_mngeOtherFees
            // 
            this.textBox_mngeOtherFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mngeOtherFees.Location = new System.Drawing.Point(471, 62);
            this.textBox_mngeOtherFees.Name = "textBox_mngeOtherFees";
            this.textBox_mngeOtherFees.Size = new System.Drawing.Size(170, 26);
            this.textBox_mngeOtherFees.TabIndex = 77;
            // 
            // label_mngeOtherfees
            // 
            this.label_mngeOtherfees.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngeOtherfees.AutoSize = true;
            this.label_mngeOtherfees.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mngeOtherfees.Location = new System.Drawing.Point(363, 61);
            this.label_mngeOtherfees.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_mngeOtherfees.Name = "label_mngeOtherfees";
            this.label_mngeOtherfees.Size = new System.Drawing.Size(98, 21);
            this.label_mngeOtherfees.TabIndex = 76;
            this.label_mngeOtherfees.Text = "Other Fees:";
            // 
            // textBox1_mngeTuition
            // 
            this.textBox1_mngeTuition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1_mngeTuition.Location = new System.Drawing.Point(471, 20);
            this.textBox1_mngeTuition.Name = "textBox1_mngeTuition";
            this.textBox1_mngeTuition.Size = new System.Drawing.Size(170, 26);
            this.textBox1_mngeTuition.TabIndex = 75;
            // 
            // label_mngeTuition
            // 
            this.label_mngeTuition.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngeTuition.AutoSize = true;
            this.label_mngeTuition.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mngeTuition.Location = new System.Drawing.Point(396, 20);
            this.label_mngeTuition.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_mngeTuition.Name = "label_mngeTuition";
            this.label_mngeTuition.Size = new System.Drawing.Size(65, 21);
            this.label_mngeTuition.TabIndex = 74;
            this.label_mngeTuition.Text = "Tuition:";
            // 
            // textBox_mngeSchoolYear
            // 
            this.textBox_mngeSchoolYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mngeSchoolYear.Location = new System.Drawing.Point(147, 61);
            this.textBox_mngeSchoolYear.Name = "textBox_mngeSchoolYear";
            this.textBox_mngeSchoolYear.Size = new System.Drawing.Size(170, 26);
            this.textBox_mngeSchoolYear.TabIndex = 73;
            // 
            // textBox_mngeStudentID
            // 
            this.textBox_mngeStudentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mngeStudentID.Location = new System.Drawing.Point(145, 114);
            this.textBox_mngeStudentID.Name = "textBox_mngeStudentID";
            this.textBox_mngeStudentID.Size = new System.Drawing.Size(170, 26);
            this.textBox_mngeStudentID.TabIndex = 72;
            // 
            // textBox_mngeEnrollmentID
            // 
            this.textBox_mngeEnrollmentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_mngeEnrollmentID.Location = new System.Drawing.Point(145, 18);
            this.textBox_mngeEnrollmentID.Name = "textBox_mngeEnrollmentID";
            this.textBox_mngeEnrollmentID.Size = new System.Drawing.Size(170, 26);
            this.textBox_mngeEnrollmentID.TabIndex = 71;
            // 
            // label_mngeSchoolYear
            // 
            this.label_mngeSchoolYear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngeSchoolYear.AutoSize = true;
            this.label_mngeSchoolYear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mngeSchoolYear.Location = new System.Drawing.Point(31, 63);
            this.label_mngeSchoolYear.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_mngeSchoolYear.Name = "label_mngeSchoolYear";
            this.label_mngeSchoolYear.Size = new System.Drawing.Size(106, 21);
            this.label_mngeSchoolYear.TabIndex = 70;
            this.label_mngeSchoolYear.Text = "School Year:";
            // 
            // label_mngeEnrollmentID
            // 
            this.label_mngeEnrollmentID.AutoSize = true;
            this.label_mngeEnrollmentID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mngeEnrollmentID.Location = new System.Drawing.Point(20, 19);
            this.label_mngeEnrollmentID.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_mngeEnrollmentID.Name = "label_mngeEnrollmentID";
            this.label_mngeEnrollmentID.Size = new System.Drawing.Size(117, 21);
            this.label_mngeEnrollmentID.TabIndex = 69;
            this.label_mngeEnrollmentID.Text = "Enrollment ID:";
            // 
            // label_mngeStudentID
            // 
            this.label_mngeStudentID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_mngeStudentID.AutoSize = true;
            this.label_mngeStudentID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mngeStudentID.Location = new System.Drawing.Point(37, 115);
            this.label_mngeStudentID.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_mngeStudentID.Name = "label_mngeStudentID";
            this.label_mngeStudentID.Size = new System.Drawing.Size(98, 21);
            this.label_mngeStudentID.TabIndex = 68;
            this.label_mngeStudentID.Text = "Student ID:";
            // 
            // button_mngefeesUpdate
            // 
            this.button_mngefeesUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_mngefeesUpdate.BackColor = System.Drawing.Color.Green;
            this.button_mngefeesUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngefeesUpdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_mngefeesUpdate.ForeColor = System.Drawing.Color.White;
            this.button_mngefeesUpdate.Location = new System.Drawing.Point(787, 106);
            this.button_mngefeesUpdate.Margin = new System.Windows.Forms.Padding(5);
            this.button_mngefeesUpdate.Name = "button_mngefeesUpdate";
            this.button_mngefeesUpdate.Size = new System.Drawing.Size(83, 30);
            this.button_mngefeesUpdate.TabIndex = 53;
            this.button_mngefeesUpdate.Text = "Update";
            this.button_mngefeesUpdate.UseVisualStyleBackColor = false;
            // 
            // button_mngefeesClear
            // 
            this.button_mngefeesClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_mngefeesClear.BackColor = System.Drawing.Color.Goldenrod;
            this.button_mngefeesClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngefeesClear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_mngefeesClear.ForeColor = System.Drawing.Color.White;
            this.button_mngefeesClear.Location = new System.Drawing.Point(687, 106);
            this.button_mngefeesClear.Margin = new System.Windows.Forms.Padding(5);
            this.button_mngefeesClear.Name = "button_mngefeesClear";
            this.button_mngefeesClear.Size = new System.Drawing.Size(81, 30);
            this.button_mngefeesClear.TabIndex = 52;
            this.button_mngefeesClear.Text = "Clear";
            this.button_mngefeesClear.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(0, 437);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 12);
            this.panel1.TabIndex = 31;
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 982);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 31);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_managefees
            // 
            this.panel_managefees.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_managefees.Controls.Add(this.button_mngfeesBack);
            this.panel_managefees.Controls.Add(this.label_manageFees);
            this.panel_managefees.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_managefees.Location = new System.Drawing.Point(0, 0);
            this.panel_managefees.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_managefees.Name = "panel_managefees";
            this.panel_managefees.Size = new System.Drawing.Size(884, 51);
            this.panel_managefees.TabIndex = 0;
            // 
            // button_mngfeesBack
            // 
            this.button_mngfeesBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_mngfeesBack.BackColor = System.Drawing.Color.White;
            this.button_mngfeesBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mngfeesBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_mngfeesBack.ForeColor = System.Drawing.Color.Black;
            this.button_mngfeesBack.Location = new System.Drawing.Point(24, 9);
            this.button_mngfeesBack.Margin = new System.Windows.Forms.Padding(5);
            this.button_mngfeesBack.Name = "button_mngfeesBack";
            this.button_mngfeesBack.Size = new System.Drawing.Size(60, 29);
            this.button_mngfeesBack.TabIndex = 47;
            this.button_mngfeesBack.Text = "Back";
            this.button_mngfeesBack.UseVisualStyleBackColor = false;
            this.button_mngfeesBack.Click += new System.EventHandler(this.button_mngfeesBack_Click);
            // 
            // label_manageFees
            // 
            this.label_manageFees.AutoSize = true;
            this.label_manageFees.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_manageFees.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_manageFees.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_manageFees.Location = new System.Drawing.Point(397, 13);
            this.label_manageFees.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_manageFees.Name = "label_manageFees";
            this.label_manageFees.Size = new System.Drawing.Size(150, 25);
            this.label_manageFees.TabIndex = 0;
            this.label_manageFees.Text = "Manage Fees";
            this.label_manageFees.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // ManageFees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_mngfeesMain);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "ManageFees";
            this.Text = "ManageFees";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_mngfeesMain.ResumeLayout(false);
            this.panel_mngfeesMain.PerformLayout();
            this.panel_mnagefeesbottom.ResumeLayout(false);
            this.panel_mnagefeesbottom.PerformLayout();
            this.panel_managefees.ResumeLayout(false);
            this.panel_managefees.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel_mngfeesMain;
        private System.Windows.Forms.Panel panel_mnagefeesbottom;
        private System.Windows.Forms.Button button_mngefeesUpdate;
        private System.Windows.Forms.Button button_mngefeesClear;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_managefees;
        private System.Windows.Forms.Button button_mngfeesBack;
        private System.Windows.Forms.Label label_manageFees;
        private System.Windows.Forms.Button button_mngefeesDelete;
        private System.Windows.Forms.TextBox textBox_mngeTotalfees;
        private System.Windows.Forms.Label label_mangeTotalfees;
        private System.Windows.Forms.TextBox textBox_mngeOtherFees;
        private System.Windows.Forms.Label label_mngeOtherfees;
        private System.Windows.Forms.TextBox textBox1_mngeTuition;
        private System.Windows.Forms.Label label_mngeTuition;
        private System.Windows.Forms.TextBox textBox_mngeSchoolYear;
        private System.Windows.Forms.TextBox textBox_mngeStudentID;
        private System.Windows.Forms.TextBox textBox_mngeEnrollmentID;
        private System.Windows.Forms.Label label_mngeSchoolYear;
        private System.Windows.Forms.Label label_mngeEnrollmentID;
        private System.Windows.Forms.Label label_mngeStudentID;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_mangefeeSearch;
    }
}