﻿namespace StudentRecordSystem
{
    partial class SubjectName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_submain = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label_subNameList = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_subNameTeacher = new System.Windows.Forms.Label();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_subName = new System.Windows.Forms.Panel();
            this.button_subNameBack = new System.Windows.Forms.Button();
            this.label_subName = new System.Windows.Forms.Label();
            this.panel_submain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel_subName.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_submain
            // 
            this.panel_submain.Controls.Add(this.dataGridView1);
            this.panel_submain.Controls.Add(this.panel1);
            this.panel_submain.Controls.Add(this.panel2);
            this.panel_submain.Controls.Add(this.panel_subBorder);
            this.panel_submain.Controls.Add(this.panel_subName);
            this.panel_submain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_submain.Location = new System.Drawing.Point(0, 0);
            this.panel_submain.Margin = new System.Windows.Forms.Padding(4);
            this.panel_submain.Name = "panel_submain";
            this.panel_submain.Size = new System.Drawing.Size(884, 611);
            this.panel_submain.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(868, 343);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(3, 413);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 10);
            this.panel1.TabIndex = 31;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.label_subNameList);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label_subNameTeacher);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 413);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(884, 198);
            this.panel2.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.Green;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(757, 137);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(96, 31);
            this.button3.TabIndex = 47;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.Goldenrod;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(634, 137);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 31);
            this.button2.TabIndex = 46;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // comboBox2
            // 
            this.comboBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(188, 97);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(220, 27);
            this.comboBox2.TabIndex = 3;
            // 
            // label_subNameList
            // 
            this.label_subNameList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subNameList.AutoSize = true;
            this.label_subNameList.Location = new System.Drawing.Point(52, 97);
            this.label_subNameList.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subNameList.Name = "label_subNameList";
            this.label_subNameList.Size = new System.Drawing.Size(123, 19);
            this.label_subNameList.TabIndex = 2;
            this.label_subNameList.Text = "Subject Name:";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(188, 48);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(220, 27);
            this.comboBox1.TabIndex = 1;
            // 
            // label_subNameTeacher
            // 
            this.label_subNameTeacher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label_subNameTeacher.AutoSize = true;
            this.label_subNameTeacher.Location = new System.Drawing.Point(52, 56);
            this.label_subNameTeacher.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subNameTeacher.Name = "label_subNameTeacher";
            this.label_subNameTeacher.Size = new System.Drawing.Size(129, 19);
            this.label_subNameTeacher.TabIndex = 0;
            this.label_subNameTeacher.Text = "Teacher Name:";
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 608);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(4);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 19);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_subName
            // 
            this.panel_subName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subName.Controls.Add(this.button_subNameBack);
            this.panel_subName.Controls.Add(this.label_subName);
            this.panel_subName.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_subName.Location = new System.Drawing.Point(0, 0);
            this.panel_subName.Margin = new System.Windows.Forms.Padding(4);
            this.panel_subName.Name = "panel_subName";
            this.panel_subName.Size = new System.Drawing.Size(884, 55);
            this.panel_subName.TabIndex = 0;
            // 
            // button_subNameBack
            // 
            this.button_subNameBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_subNameBack.BackColor = System.Drawing.Color.White;
            this.button_subNameBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_subNameBack.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_subNameBack.ForeColor = System.Drawing.Color.Black;
            this.button_subNameBack.Location = new System.Drawing.Point(12, 12);
            this.button_subNameBack.Name = "button_subNameBack";
            this.button_subNameBack.Size = new System.Drawing.Size(58, 28);
            this.button_subNameBack.TabIndex = 47;
            this.button_subNameBack.Text = "Back";
            this.button_subNameBack.UseVisualStyleBackColor = false;
            this.button_subNameBack.Click += new System.EventHandler(this.button_subNameBack_Click);
            // 
            // label_subName
            // 
            this.label_subName.AutoSize = true;
            this.label_subName.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_subName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_subName.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_subName.Location = new System.Drawing.Point(404, 9);
            this.label_subName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_subName.Name = "label_subName";
            this.label_subName.Size = new System.Drawing.Size(156, 25);
            this.label_subName.TabIndex = 0;
            this.label_subName.Text = "Subject Name";
            this.label_subName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // SubjectName
            // 
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_submain);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SubjectName";
            this.Text = "SubjectName";
            this.panel_submain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel_subName.ResumeLayout(false);
            this.panel_subName.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_submain;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_subName;
        private System.Windows.Forms.Label label_subName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label_subNameTeacher;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label_subNameList;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button_subNameBack;
    }
}