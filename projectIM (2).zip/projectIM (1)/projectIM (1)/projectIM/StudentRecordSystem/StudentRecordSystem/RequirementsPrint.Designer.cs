﻿namespace StudentRecordSystem
{
    partial class RequirementsPrint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_reqPrintBack = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_reqPrintMain = new System.Windows.Forms.Panel();
            this.panel_reqPrintBottom = new System.Windows.Forms.Panel();
            this.button_reqPrint = new System.Windows.Forms.Button();
            this.panel_subBorder = new System.Windows.Forms.Panel();
            this.panel_RequirementPrint = new System.Windows.Forms.Panel();
            this.label_RequirementPrint = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_reqPrintMain.SuspendLayout();
            this.panel_reqPrintBottom.SuspendLayout();
            this.panel_RequirementPrint.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_reqPrintBack
            // 
            this.button_reqPrintBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button_reqPrintBack.BackColor = System.Drawing.Color.White;
            this.button_reqPrintBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reqPrintBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_reqPrintBack.ForeColor = System.Drawing.Color.Black;
            this.button_reqPrintBack.Location = new System.Drawing.Point(28, 9);
            this.button_reqPrintBack.Margin = new System.Windows.Forms.Padding(5);
            this.button_reqPrintBack.Name = "button_reqPrintBack";
            this.button_reqPrintBack.Size = new System.Drawing.Size(60, 29);
            this.button_reqPrintBack.TabIndex = 47;
            this.button_reqPrintBack.Text = "Back";
            this.button_reqPrintBack.UseVisualStyleBackColor = false;
            this.button_reqPrintBack.Click += new System.EventHandler(this.button_reqPrintBack_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 62);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(856, 440);
            this.dataGridView1.TabIndex = 32;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel1.Location = new System.Drawing.Point(0, 512);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(884, 12);
            this.panel1.TabIndex = 31;
            // 
            // panel_reqPrintMain
            // 
            this.panel_reqPrintMain.Controls.Add(this.panel_reqPrintBottom);
            this.panel_reqPrintMain.Controls.Add(this.dataGridView1);
            this.panel_reqPrintMain.Controls.Add(this.panel1);
            this.panel_reqPrintMain.Controls.Add(this.panel_subBorder);
            this.panel_reqPrintMain.Controls.Add(this.panel_RequirementPrint);
            this.panel_reqPrintMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_reqPrintMain.Location = new System.Drawing.Point(0, 0);
            this.panel_reqPrintMain.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_reqPrintMain.Name = "panel_reqPrintMain";
            this.panel_reqPrintMain.Size = new System.Drawing.Size(884, 611);
            this.panel_reqPrintMain.TabIndex = 5;
            // 
            // panel_reqPrintBottom
            // 
            this.panel_reqPrintBottom.Controls.Add(this.button_reqPrint);
            this.panel_reqPrintBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_reqPrintBottom.Location = new System.Drawing.Point(0, 522);
            this.panel_reqPrintBottom.Margin = new System.Windows.Forms.Padding(5);
            this.panel_reqPrintBottom.Name = "panel_reqPrintBottom";
            this.panel_reqPrintBottom.Size = new System.Drawing.Size(884, 89);
            this.panel_reqPrintBottom.TabIndex = 33;
            // 
            // button_reqPrint
            // 
            this.button_reqPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_reqPrint.BackColor = System.Drawing.Color.Teal;
            this.button_reqPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reqPrint.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_reqPrint.ForeColor = System.Drawing.Color.White;
            this.button_reqPrint.Location = new System.Drawing.Point(716, 26);
            this.button_reqPrint.Margin = new System.Windows.Forms.Padding(5);
            this.button_reqPrint.Name = "button_reqPrint";
            this.button_reqPrint.Size = new System.Drawing.Size(119, 39);
            this.button_reqPrint.TabIndex = 53;
            this.button_reqPrint.Text = "Print";
            this.button_reqPrint.UseVisualStyleBackColor = false;
            // 
            // panel_subBorder
            // 
            this.panel_subBorder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_subBorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_subBorder.Location = new System.Drawing.Point(0, 982);
            this.panel_subBorder.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_subBorder.Name = "panel_subBorder";
            this.panel_subBorder.Size = new System.Drawing.Size(884, 31);
            this.panel_subBorder.TabIndex = 1;
            // 
            // panel_RequirementPrint
            // 
            this.panel_RequirementPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_RequirementPrint.Controls.Add(this.button_reqPrintBack);
            this.panel_RequirementPrint.Controls.Add(this.label_RequirementPrint);
            this.panel_RequirementPrint.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_RequirementPrint.Location = new System.Drawing.Point(0, 0);
            this.panel_RequirementPrint.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.panel_RequirementPrint.Name = "panel_RequirementPrint";
            this.panel_RequirementPrint.Size = new System.Drawing.Size(884, 51);
            this.panel_RequirementPrint.TabIndex = 0;
            // 
            // label_RequirementPrint
            // 
            this.label_RequirementPrint.AutoSize = true;
            this.label_RequirementPrint.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_RequirementPrint.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_RequirementPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_RequirementPrint.Location = new System.Drawing.Point(335, 13);
            this.label_RequirementPrint.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label_RequirementPrint.Name = "label_RequirementPrint";
            this.label_RequirementPrint.Size = new System.Drawing.Size(205, 25);
            this.label_RequirementPrint.TabIndex = 0;
            this.label_RequirementPrint.Text = "Print Requirements ";
            this.label_RequirementPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // RequirementsPrint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 611);
            this.Controls.Add(this.panel_reqPrintMain);
            this.MinimumSize = new System.Drawing.Size(900, 650);
            this.Name = "RequirementsPrint";
            this.Text = "RequirementsPrint";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_reqPrintMain.ResumeLayout(false);
            this.panel_reqPrintBottom.ResumeLayout(false);
            this.panel_RequirementPrint.ResumeLayout(false);
            this.panel_RequirementPrint.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_reqPrintBack;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_reqPrintMain;
        private System.Windows.Forms.Panel panel_reqPrintBottom;
        private System.Windows.Forms.Button button_reqPrint;
        private System.Windows.Forms.Panel panel_subBorder;
        private System.Windows.Forms.Panel panel_RequirementPrint;
        private System.Windows.Forms.Label label_RequirementPrint;
    }
}